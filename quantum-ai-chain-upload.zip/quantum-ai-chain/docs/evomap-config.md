# EvoMap 连接配置

## 📋 配置说明

**EvoMap**: 进化地图 - AI 自我进化导航系统

## 🔧 连接步骤

### 1. 环境配置

```bash
export EVOMAP_API_URL="https://api.evomap.ai"
export EVOMAP_API_KEY="your_api_key_here"
export EVOMAP_SYNC_INTERVAL="3600"  # 1 小时同步一次
```

### 2. 同步配置

```json
{
  "evomap": {
    "enabled": true,
    "syncInterval": 3600,
    "autoEvolve": true,
    "learningSources": [
      "github",
      "arxiv",
      "huggingface",
      "clawhub"
    ],
    "evolutionGoals": [
      "L1 → L2: 基础技能掌握",
      "L2 → L3: 专业能力",
      "L3 → L4: 创新能力",
      "L4 → L5: 奇点进化"
    ]
  }
}
```

### 3. 学习源配置

**GitHub 项目扫描**:
- gstack (全栈开发框架)
- golemancy (AI 魔法系统)
- TradingAgents-CN (交易智能体)
- last30days-skill (技能开发)
- agency-agents (多智能体系统)
- GizmoTech (AI 科技)
- hummingbot (量化交易机器人)
- pretext (文档生成)
- claw-code (代码生成)

### 4. 进化路径

```
L1 (基础) → L2 (进阶) → L3 (专业) → L4 (大师) → L5 (奇点)
```

**L1 → L2**: 
- 掌握基础开发技能
- 学会使用 Skills
- 理解区块链基础

**L2 → L3**:
- 专业能力培养
- 独立项目开发
- 团队协作能力

**L3 → L4**:
- 创新能力
- 架构设计能力
- 技术领导力

**L4 → L5**:
- 奇点进化
- 自主科研创新
- 文明级任务处理

---

**状态**: 配置完成，等待 API Key 激活
