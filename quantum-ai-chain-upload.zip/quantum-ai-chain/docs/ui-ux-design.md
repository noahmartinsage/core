# 量子 AI 公链 - UI/UX 设计规范 v1.0

## 📋 版本说明

**决策**: B - UI/UX 设计细化
**阶段**: Phase 1 (界面设计)
**优先级**: P0
**参考**: 用户提供的 UI 截图 + 量子 AI 公链文档

---

## 🎨 设计理念

### 核心设计原则

**1. 量子科技感**
- 深空黑 + 量子蓝 + 霓虹紫配色
- 粒子动画效果
-  holographic 全息视觉元素

**2. AI 智能化**
- 智能推荐算法
- 个性化界面
- 语音交互支持

**3. Web3 去中心化**
- 钱包地址展示
- 链上数据实时显示
- NFT 资产可视化

**4. 移动端优先**
- 响应式设计
- 手势操作优化
- 离线模式支持

---

## 📱 移动端界面设计

### 首页设计 (参考截图)

**顶部导航栏**:
```
┌─────────────────────────────────────┐
│ [短视频] web3.0   🔔 ⚙️            │
├─────────────────────────────────────┤
│  👤 用户头像                         │
│  d11:0xB69...8bB786b4  [复制]      │
│  0 关注 · 0 粉丝 · 0.0 喜欢         │
└─────────────────────────────────────┘
```

**资产业绩区**:
```
┌─────────────────────────────────────┐
│  X 团队业绩  Y 团队业绩  有效直推    │
│      0           0           0       │
└─────────────────────────────────────┘
```

**资产总额卡片**:
```
┌─────────────────────────────────────┐
│  资产总额≈ (USDT)           👁️ 💼  │
│  ────────────────────────           │
│  0.00                               │
│  ────────────────────────           │
│  [↓充币]  [↑提币]  [⇄划转]         │
└─────────────────────────────────────┘
```

**边看边赚卡片**:
```
┌─────────────────────────────────────┐
│  边看边赚 (MOKA)            👁️ ▶️  │
│  ────────────────────────           │
│  0.00                               │
│  ────────────────────────           │
│  [●] 释放 ** MOKA/小时              │
└─────────────────────────────────────┘
```

**功能网格区** (4 列×4 行):
```
┌──────┬──────┬──────┬──────┐
│ 🎁   │ 📊   │ 👥   │    │
│奖励  │我的  │我的  │商城  │
│任务  │收益  │团队  │订单  │
├────────────┼────────────┤
│    │    │     │ 🔗   │
│交易  │我的  │绑定  │Moka  │
│市场  │盲盒  │上级  │大学  │
├────────────┼────────────┤
│    │ 📱   │ 🟢   │ ️   │
│帮助  │谷歌  │算力  │邀请  │
│中心  │验证  │挖矿  │码    │
└──────┴──────┴──────┴──────┘
```

**底部导航栏**:
```
┌──────┬──────┬──────┬──────┬──────┐
│ 🏠   │     │ 🌐   │ 💬   │ 👤   │
│首页  │UP 主 │生态  │消息  │我的  │
└────────────┴────────────┴──────
```

---

### 配色方案

**主色调**:
```css
:root {
  /* 背景色 */
  --bg-primary: #0A0A0F;        /* 深空黑 */
  --bg-secondary: #12121A;      /* 深灰蓝 */
  --bg-card: #1A1A25;           /* 卡片背景 */
  
  /* 主色 */
  --primary-blue: #0066FF;      /* 量子蓝 */
  --primary-purple: #7B2CBF;    /* 霓虹紫 */
  --primary-cyan: #00D9FF;      /* 量子青 */
  
  /* 强调色 */
  --accent-pink: #FF006E;       /* 活力粉 */
  --accent-green: #00FF88;      /* 生态绿 */
  --accent-yellow: #FFBE00;     /* 警告黄 */
  
  /* 文字色 */
  --text-primary: #FFFFFF;      /* 主文字 */
  --text-secondary: #A0A0B0;    /* 次要文字 */
  --text-muted: #606070;        /* 弱化文字 */
  
  /* 渐变色 */
  --gradient-1: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  --gradient-2: linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  --gradient-3: linear-gradient(135deg, #FF006E 0%, #FFBE00 100%);
}
```

---

### 字体规范

**中文字体**:
```css
font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
```

**数字字体**:
```css
font-family: 'DIN Alternate', 'Roboto Mono', monospace;
```

**字号规范**:
```
特大标题：32px / 2rem
大标题：24px / 1.5rem
中标题：18px / 1.125rem
小标题：16px / 1rem
正文：14px / 0.875rem
辅助文字：12px / 0.75rem
微小文字：10px / 0.625rem
```

---

## 🖥️ Web 端界面设计

### 响应式布局

**桌面端 (≥1440px)**:
```
┌─────────────────────────────────────────────────┐
│  Header (Logo + 导航 + 钱包连接)                 │
├─────────┬─────────────────────────┬─────────────┤
│ Sidebar │    Main Content         │  RightPanel │
│ 250px   │    自适应宽度            │  300px      │
├─────────┴─────────────────────────┴─────────────┤
│  Footer                                         │
└─────────────────────────────────────────────────┘
```

**平板端 (768px-1439px)**:
```
┌─────────────────────────────────────┐
│  Header (响应式导航)                 │
├─────────────────────────────────────┤
│    Main Content (全宽)              │
├─────────────────────────────────────┤
│  Footer                             │
└─────────────────────────────────────┘
```

**移动端 (≤767px)**:
```
┌─────────────────────────┐
│  Header (汉堡菜单)       │
├─────────────────────────┤
│    Main Content         │
├─────────────────────────┤
│  Bottom Navigation      │
└─────────────────────────┘
```

---

## 🎯 核心功能模块

### 1. 钱包管理模块

**功能列表**:
- [ ] 钱包创建/导入
- [ ] 多链支持 (QAI/BTC/ETH/SOL)
- [ ] 资产总额显示
- [ ] 充币/提币/划转
- [ ] 交易历史
- [ ] 地址簿管理

**UI 组件**:
```vue
<template>
  <div class="wallet-card">
    <div class="wallet-header">
      <span class="wallet-title">资产总额≈ (USDT)</span>
      <button class="eye-btn">👁️</button>
      <button class="wallet-btn">💼</button>
    </div>
    <div class="wallet-balance">
      <span class="balance-amount">{{ balance }}</span>
    </div>
    <div class="wallet-actions">
      <button class="action-btn deposit">
        <span class="icon">↓</span>
        <span class="label">充币</span>
      </button>
      <button class="action-btn withdraw">
        <span class="icon">↑</span>
        <span class="label">提币</span>
      </button>
      <button class="action-btn transfer">
        <span class="icon">⇄</span>
        <span class="label">划转</span>
      </button>
    </div>
  </div>
</template>
```

---

### 2. 边看边赚模块

**功能列表**:
- [ ] 视频播放
- [ ] MOKA 释放速率显示
- [ ] 累计收益统计
- [ ] 提现功能
- [ ] 任务列表

**UI 组件**:
```vue
<template>
  <div class="earn-card">
    <div class="earn-header">
      <span class="earn-title">边看边赚 (MOKA)</span>
      <button class="eye-btn">👁️</button>
      <button class="play-btn">▶️</button>
    </div>
    <div class="earn-balance">
      <span class="balance-amount">{{ mokaBalance }}</span>
    </div>
    <div class="earn-rate">
      <span class="rate-indicator">●</span>
      <span class="rate-text">释放 {{ releaseRate }} MOKA/小时</span>
    </div>
  </div>
</template>
```

---

### 3. 功能导航模块

**功能网格**:
```typescript
interface FunctionGridItem {
  icon: string;
  label: string;
  route: string;
  badge?: number;
  gradient: string;
}

const functionGrid: FunctionGridItem[] = [
  { icon: '🎁', label: '奖励任务', route: '/tasks', gradient: 'gradient-1' },
  { icon: '📊', label: '我的收益', route: '/earnings', gradient: 'gradient-2' },
  { icon: '👥', label: '我的团队', route: '/team', gradient: 'gradient-3' },
  { icon: '🛒', label: '商城订单', route: '/orders', gradient: 'gradient-1' },
  { icon: '🏪', label: '交易市场', route: '/market', gradient: 'gradient-2' },
  { icon: '🎁', label: '我的盲盒', route: '/blindbox', gradient: 'gradient-3' },
  { icon: '⭐', label: '绑定上级', route: '/bind', gradient: 'gradient-1' },
  { icon: '🎓', label: 'Moka 大学', route: '/university', gradient: 'gradient-2' },
  { icon: '❓', label: '帮助中心', route: '/help', gradient: 'gradient-3' },
  { icon: '📱', label: '谷歌验证', route: '/2fa', gradient: 'gradient-1' },
  { icon: '⛏️', label: '算力挖矿', route: '/mining', gradient: 'gradient-2' },
  { icon: '🔗', label: '邀请码', route: '/invite', gradient: 'gradient-3' },
];
```

---

## 🎬 动画效果

### 粒子背景动画
```css
@keyframes particleFloat {
  0%, 100% {
    transform: translateY(0) translateX(0);
    opacity: 0;
  }
  50% {
    transform: translateY(-100px) translateX(50px);
    opacity: 0.5;
  }
}

.particle {
  position: absolute;
  width: 4px;
  height: 4px;
  background: radial-gradient(circle, #0066FF 0%, transparent 70%);
  animation: particleFloat 10s infinite;
}
```

### 卡片悬浮效果
```css
.card {
  transition: all 0.3s ease;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
}
```

### 数字滚动动画
```javascript
function animateNumber(element, target, duration = 2000) {
  const start = 0;
  const increment = (target - start) / (duration / 16);
  let current = start;
  
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    element.textContent = current.toFixed(2);
  }, 16);
}
```

---

## 📱 移动端优化

### 手势操作

**支持手势**:
- 左滑：返回
- 右滑：前进
- 下拉：刷新
- 上拉：加载更多
- 双击：点赞/收藏
- 长按：菜单

### 性能优化

**优化策略**:
```
1. 图片懒加载
2. 虚拟列表 (长列表)
3. 资源预加载
4. Service Worker 缓存
5. 骨架屏加载
6. 离线模式支持
```

---

## 🎨 设计资源

### 图标库

**推荐图标**:
- Material Icons
- Font Awesome
- Remix Icon
- 自定义 SVG 图标

### 设计工具

**推荐工具**:
- Figma (UI 设计)
- Sketch (UI 设计)
- Adobe XD (原型设计)
- Principle (交互动画)

---

## 📁 文件结构

```
apps/wallet/
├── src/
│   ├── components/
│   │   ├── WalletCard.vue
│   │   ├── EarnCard.vue
│   │   ├── FunctionGrid.vue
│   │   └── BottomNav.vue
│   ├── views/
│   │   ├── Home.vue
│   │   ├── Earnings.vue
│   │   ├── Team.vue
│   │   └── Market.vue
│   ├── styles/
│   │   ├── variables.scss
│   │   ├── global.scss
│   │   └── animations.scss
│   └── utils/
│       ├── animations.js
│       └── formatters.js
├── public/
│   └── assets/
│       ├── icons/
│       └── images/
└── package.json
```

---

**版本**: v1.0
**创建时间**: 2026-04-01 18:40
**状态**: 设计完成，待开发
**下一步**: UI 组件开发 (Phase 1 M1.3)
