# 量子 AI 公链 - 开发者 API 文档

## 📚 概述

量子 AI 公链提供完整的开发者 API，支持智能合约开发、DApp 集成、钱包接入等功能。

---

## 🔗 网络配置

### 测试网

| 参数 | 值 |
|------|-----|
| **网络名称** | Quantum AI Testnet |
| **Chain ID** | 1001 |
| **RPC URL** | https://testnet-rpc.quantum-ai-chain.org |
| **WebSocket** | wss://testnet-ws.quantum-ai-chain.org |
| **区块浏览器** | https://testnet-explorer.quantum-ai-chain.org |
| ** Faucet** | https://faucet.quantum-ai-chain.org |

### 主网 (待上线)

| 参数 | 值 |
|------|-----|
| **网络名称** | Quantum AI Mainnet |
| **Chain ID** | 1000 |
| **RPC URL** | https://rpc.quantum-ai-chain.org |
| **WebSocket** | wss://ws.quantum-ai-chain.org |
| **区块浏览器** | https://explorer.quantum-ai-chain.org |

---

## 📦 SDK 使用

### JavaScript/TypeScript

```javascript
import { QuantumClient } from '@quantum-ai-chain/sdk';

const client = new QuantumClient({
  network: 'testnet',
  nodeUrl: 'https://testnet-rpc.quantum-ai-chain.org'
});

// 查询余额
const balance = await client.getBalance('0x...');

// 发送交易
const tx = await client.sendTransaction({
  from: '0x...',
  to: '0x...',
  amount: '1000000000000000000', // 1 QAI
});

// 调用合约
const result = await client.callContract({
  contractAddress: '0x...',
  function: 'transfer',
  args: ['0x...', 1000],
});
```

### Python

```python
from quantum_ai_chain import QuantumClient

client = QuantumClient(network='testnet')

# 查询余额
balance = client.get_balance('0x...')

# 发送交易
tx = client.send_transaction(
    from_='0x...',
    to='0x...',
    amount=1000000000000000000
)
```

### Go

```go
import "github.com/quantum-ai-chain/sdk-go"

client := quantum.NewClient(quantum.Testnet)

// 查询余额
balance, err := client.GetBalance(ctx, "0x...")

// 发送交易
tx, err := client.SendTransaction(ctx, &quantum.Transaction{
    From:   "0x...",
    To:     "0x...",
    Amount: big.NewInt(1000000000000000000),
})
```

---

## 🔌 RPC API

### eth_blockNumber

获取最新区块高度

**请求**:
```json
{
  "jsonrpc": "2.0",
  "method": "eth_blockNumber",
  "params": [],
  "id": 1
}
```

**响应**:
```json
{
  "jsonrpc": "2.0",
  "result": "0x12d68f",
  "id": 1
}
```

### eth_getBalance

查询账户余额

**请求**:
```json
{
  "jsonrpc": "2.0",
  "method": "eth_getBalance",
  "params": ["0x...", "latest"],
  "id": 1
}
```

### eth_sendTransaction

发送交易

**请求**:
```json
{
  "jsonrpc": "2.0",
  "method": "eth_sendTransaction",
  "params": [{
    "from": "0x...",
    "to": "0x...",
    "value": "0xde0b6b3a7640000",
    "gas": "0x5208",
    "gasPrice": "0x4a817c800"
  }],
  "id": 1
}
```

### eth_call

调用合约函数

**请求**:
```json
{
  "jsonrpc": "2.0",
  "method": "eth_call",
  "params": [{
    "to": "0x...",
    "data": "0xa9059cbb..."
  }, "latest"],
  "id": 1
}
```

---

## 📝 智能合约开发

### 开发环境

```bash
# 安装 Hardhat
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox

# 初始化项目
npx hardhat init

# 配置 hardhat.config.js
module.exports = {
  solidity: "0.8.19",
  networks: {
    quantumTestnet: {
      url: "https://testnet-rpc.quantum-ai-chain.org",
      chainId: 1001,
      accounts: [process.env.PRIVATE_KEY]
    }
  }
};
```

### 部署合约

```bash
# 编译
npx hardhat compile

# 部署到测试网
npx hardhat run scripts/deploy.js --network quantumTestnet
```

### 验证合约

```bash
# 验证合约
npx hardhat verify --network quantumTestnet DEPLOYED_CONTRACT_ADDRESS
```

---

## 🎯 AI 智能体集成

### 通过 API 调用 AI 管家

```javascript
const aiResponse = await fetch('https://ai.quantum-ai-chain.org/api/v1/ask', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    question: '我的账户余额是多少？',
    address: '0x...'
  })
});

const result = await aiResponse.json();
console.log(result.answer);
```

### AI 分析账户

```javascript
const analysis = await fetch('https://ai.quantum-ai-chain.org/api/v1/analyze', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    address: '0x...',
    analysisType: 'portfolio'
  })
});
```

---

## 🛍️ 商城集成

### 上架商品

```javascript
const productId = await marketplace.listProduct({
  name: '商品名称',
  description: '商品描述',
  price: ethers.parseEther('100'),
  supply: 1000,
  isNFT: true,
  ipfsHash: 'Qm...'
});
```

### 购买商品

```javascript
const orderId = await marketplace.buyProduct(productId, {
  value: ethers.parseEther('100')
});
```

### 查询溯源信息

```javascript
const traceInfo = await marketplace.getTraceInfo(productId);
console.log('原产地:', traceInfo.origin);
console.log('生产商:', traceInfo.manufacturer);
```

---

## 💰 金融模块集成

### 创建理财产品

```javascript
const productId = await bank.createWealthProduct({
  name: '稳健理财 30 天',
  apy: 800, // 8%
  minAmount: ethers.parseEther('100'),
  lockPeriod: 30
});
```

### 存入理财

```javascript
await bank.depositWealth(productId, {
  value: ethers.parseEther('1000')
});
```

### 申请贷款

```javascript
const loanId = await bank.applyLoan(
  ethers.parseEther('5000'),
  30 // 30 天
);
```

---

## 📊 监控与统计

### 网络统计

```javascript
const stats = await fetch('https://api.quantum-ai-chain.org/v1/stats');
const data = await stats.json();

console.log('TPS:', data.tps);
console.log('总交易数:', data.totalTransactions);
console.log('活跃地址:', data.activeAddresses);
```

### 账户分析

```javascript
const analysis = await fetch('https://api.quantum-ai-chain.org/v1/accounts/0x...');
const data = await analysis.json();

console.log('余额:', data.balance);
console.log('交易次数:', data.transactionCount);
console.log('质押量:', data.staked);
```

---

## 📞 技术支持

- **文档**: https://docs.quantum-ai-chain.org
- **GitHub**: https://github.com/noahmartinsage/core
- **Discord**: https://discord.gg/quantum-ai
- **邮箱**: dev@quantum-ai-chain.org

---

**最后更新**: 2026-04-06
