# 智能合约系统 - 详细设计 v1.0

## 📋 版本说明

**决策**: B - 继续细化设计
**阶段**: Phase 1 (合约详细设计)
**优先级**: P0

---

## 🏗️ 合约架构

### 合约分层

```
┌─────────────────────────────────────────────────────────┐
│                  应用层合约                              │
│  • DeFi 协议 (DEX/Lending/Staking)                      │
│  • NFT 市场 (ERC-721/ERC-1155)                          │
│  • DAO 治理 (投票/提案)                                  │
│  • 游戏/社交 DApp                                        │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                  基础层合约                              │
│  • ERC-20 代币合约 (QAI)                                │
│  • 质押合约 (Staking)                                   │
│  • 验证者管理合约                                       │
│  • 奖励分配合约                                         │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                  核心层合约                              │
│  • 共识合约 (PoS 逻辑)                                   │
│  • 状态预编译合约                                       │
│  • 跨链桥合约                                           │
│  • Gas 计价合约                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 📝 核心合约设计

### 1. QAI 代币合约 (ERC-20)

**合约地址**: 待部署
**标准**: ERC-20 + ERC-2612 (Permit)

**核心功能**:
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract QAIToken is ERC20, ERC20Permit, Ownable {
    // 常量定义
    uint256 public constant TOTAL_SUPPLY = 1_000_000_000 * 10**18; // 10 亿枚
    uint256 public constant INITIAL_PRICE = 0.15 * 10**18; // $0.15
    
    // 分配映射
    mapping(address => uint256) public ecosystemFund;
    mapping(address => uint256) public communityMining;
    mapping(address => uint256) public teamIncentive;
    mapping(address => uint256) public publicSale;
    mapping(address => uint256) public advisorReserve;
    
    // 解锁时间表
    struct VestingSchedule {
        uint256 totalAmount;
        uint256 releasedAmount;
        uint256 startTime;
        uint256 cliffDuration;
        uint256 vestingDuration;
        bool isRevocable;
    }
    
    mapping(address => VestingSchedule) public vestingSchedules;
    
    // 事件
    event TokensReleased(address indexed beneficiary, uint256 amount);
    event VestingRevoked(address indexed beneficiary);
    
    constructor() ERC20("Quantum AI Token", "QAI") ERC20Permit("Quantum AI Token") {
        // 初始分配
        _mint(address(this), TOTAL_SUPPLY);
        
        // 转移到各分配账户
        ecosystemFund[owner()] = TOTAL_SUPPLY * 30 / 100;
        communityMining[address(0)] = TOTAL_SUPPLY * 25 / 100;
        teamIncentive[owner()] = TOTAL_SUPPLY * 20 / 100;
        publicSale[owner()] = TOTAL_SUPPLY * 15 / 100;
        advisorReserve[owner()] = TOTAL_SUPPLY * 10 / 100;
    }
    
    /**
     * @dev 释放解锁的代币
     */
    function releaseVestedTokens(address beneficiary) external {
        VestingSchedule memory schedule = vestingSchedules[beneficiary];
        require(schedule.totalAmount > 0, "No vesting schedule");
        
        uint256 releasable = calculateReleasableAmount(beneficiary);
        require(releasable > 0, "No tokens to release");
        
        vestingSchedules[beneficiary].releasedAmount += releasable;
        _transfer(address(this), beneficiary, releasable);
        
        emit TokensReleased(beneficiary, releasable);
    }
    
    /**
     * @dev 计算可释放数量
     */
    function calculateReleasableAmount(address beneficiary) public view returns (uint256) {
        VestingSchedule memory schedule = vestingSchedules[beneficiary];
        
        if (schedule.totalAmount == 0) {
            return 0;
        }
        
        uint256 timeSinceStart = block.timestamp - schedule.startTime;
        
        // Cliff 期未结束
        if (timeSinceStart < schedule.cliffDuration) {
            return 0;
        }
        
        // 全部解锁
        if (timeSinceStart >= schedule.vestingDuration) {
            return schedule.totalAmount - schedule.releasedAmount;
        }
        
        // 线性解锁
        uint256 totalVested = (schedule.totalAmount * timeSinceStart) / schedule.vestingDuration;
        return totalVested - schedule.releasedAmount;
    }
    
    /**
     * @dev 创建解锁计划
     */
    function createVestingSchedule(
        address beneficiary,
        uint256 totalAmount,
        uint256 startTime,
        uint256 cliffDuration,
        uint256 vestingDuration,
        bool isRevocable
    ) external onlyOwner {
        require(vestingSchedules[beneficiary].totalAmount == 0, "Schedule exists");
        require(totalAmount > 0, "Amount must be positive");
        
        vestingSchedules[beneficiary] = VestingSchedule({
            totalAmount: totalAmount,
            releasedAmount: 0,
            startTime: startTime,
            cliffDuration: cliffDuration,
            vestingDuration: vestingDuration,
            isRevocable: isRevocable
        });
        
        // 转移代币到合约
        _transfer(owner(), address(this), totalAmount);
    }
}
```

**安全特性**:
- ✅ Ownable 权限控制
- ✅ ReentrancyGuard 防重入
- ✅ Pausable 紧急暂停
- ✅ 解锁时间锁
- ✅ 多签钱包集成

---

### 2. 验证者管理合约

**功能**:
- 验证者注册/注销
- 质押/解绑管理
- Slashing 执行
- 奖励分配

**核心接口**:
```solidity
interface IValidatorManager {
    // 验证者结构
    struct Validator {
        address operator;
        address consensusKey;
        uint256 stake;
        uint256 rewards;
        bool isActive;
        uint256 jailTime;
        uint256 lastHeartbeat;
    }
    
    // 事件
    event ValidatorRegistered(address indexed operator, uint256 stake);
    event ValidatorUnregistered(address indexed operator);
    event StakeAdded(address indexed operator, uint256 amount);
    event StakeRemoved(address indexed operator, uint256 amount);
    event SlashingExecuted(address indexed operator, uint256 amount, string reason);
    event RewardsDistributed(address indexed operator, uint256 amount);
    
    // 验证者管理
    function registerValidator(address consensusKey) external payable;
    function unregisterValidator() external;
    function addStake() external payable;
    function removeStake(uint256 amount) external;
    
    // Slashing
    function slashValidator(address operator, uint256 percentage, string calldata reason) external;
    
    // 奖励
    function claimRewards() external;
    function distributeRewards() external;
    
    // 查询
    function getValidator(address operator) external view returns (Validator memory);
    function getValidatorCount() external view returns (uint256);
    function getTotalStake() external view returns (uint256);
}
```

---

### 3. 质押合约

**功能**:
- 用户质押 QAI
- 奖励计算
- 解锁期管理
- 委托质押

**核心逻辑**:
```solidity
contract QAIStaking is Ownable, ReentrancyGuard {
    IERC20 public immutable QAI;
    
    // 质押信息
    struct StakeInfo {
        uint256 amount;
        uint256 rewards;
        uint256 lastUpdateTime;
        uint256 unlockTime;
    }
    
    mapping(address => StakeInfo) public stakes;
    
    // 奖励参数
    uint256 public rewardRate; // 每秒奖励
    uint256 public lastUpdateTime;
    uint256 public rewardPerTokenStored;
    
    // 常量
    uint256 public constant UNLOCK_PERIOD = 7 days;
    uint256 public constant MIN_STAKE = 1000 * 10**18; // 1000 QAI
    
    /**
     * @dev 质押 QAI
     */
    function stake(uint256 amount) external nonReentrant {
        require(amount >= MIN_STAKE, "Below minimum stake");
        
        StakeInfo storage stake = stakes[msg.sender];
        
        // 更新奖励
        _updateReward(msg.sender);
        
        // 增加质押
        stake.amount += amount;
        stake.unlockTime = block.timestamp + UNLOCK_PERIOD;
        
        // 转移代币
        QAI.transferFrom(msg.sender, address(this), amount);
        
        emit Staked(msg.sender, amount);
    }
    
    /**
     * @dev 解绑质押
     */
    function unstake(uint256 amount) external nonReentrant {
        StakeInfo storage stake = stakes[msg.sender];
        require(stake.amount >= amount, "Insufficient stake");
        
        // 更新奖励
        _updateReward(msg.sender);
        
        // 减少质押
        stake.amount -= amount;
        
        // 转移代币 (需等待解锁期)
        // 实际实现需要单独的 claim 函数
        
        emit Unstaked(msg.sender, amount);
    }
    
    /**
     * @dev 获取待领取奖励
     */
    function earned(address account) public view returns (uint256) {
        StakeInfo memory stake = stakes[account];
        uint256 timeSinceUpdate = block.timestamp - stake.lastUpdateTime;
        
        return stake.rewards + (timeSinceUpdate * rewardRate * stake.amount) / totalStake();
    }
    
    /**
     * @dev 领取奖励
     */
    function claimRewards() external nonReentrant {
        _updateReward(msg.sender);
        
        StakeInfo storage stake = stakes[msg.sender];
        uint256 reward = stake.rewards;
        
        if (reward > 0) {
            stake.rewards = 0;
            QAI.transfer(msg.sender, reward);
            emit RewardPaid(msg.sender, reward);
        }
    }
}
```

---

## 🛡️ 安全设计

### 安全检查清单

**智能合约安全**:
```
- [ ] 重入攻击防护 (ReentrancyGuard)
- [ ] 整数溢出/下溢 (Solidity 0.8+)
- [ ] 权限控制 (Ownable/AccessControl)
- [ ] 随机数安全 (Chainlink VRF)
- [ ] 时间戳依赖 (避免 block.timestamp 精确判断)
- [ ] 前端运行防护 (slippage 保护)
- [ ] 闪电贷攻击防护 (时间加权价格)
- [ ] 价格操纵防护 (多预言机)
- [ ] Gas 限制优化
- [ ] 紧急暂停机制 (Pausable)
```

### 审计流程

**内部审计**:
```
1. 代码审查 (开发团队)
2. 静态分析 (Slither/Mythril)
3. 单元测试 (覆盖率≥90%)
4. 集成测试
5. 模糊测试
```

**外部审计**:
```
1. 审计公司选择 (CertiK/Trail of Bits/OpenZeppelin)
2. 审计范围定义
3. 问题整改
4. 审计报告发布
5. 社区公示
```

---

## 📁 合约文件结构

```
contracts/
├── token/
│   ├── QAIToken.sol              # QAI 代币合约
│   ├── VestingSchedule.sol       # 解锁计划
│   └── interfaces/
│       ├── IERC20.sol
│       └── IERC20Permit.sol
├── staking/
│   ├── ValidatorManager.sol      # 验证者管理
│   ├── QAIStaking.sol            # 质押合约
│   ├── RewardDistributor.sol     # 奖励分配
│   └── SlashingHandler.sol       # Slashing 处理
├── governance/
│   ├── Governor.sol              # DAO 治理
│   ├── Timelock.sol              # 时间锁
│   └── VotingPower.sol           # 投票权
├── bridge/
│   ├── CrossChainBridge.sol      # 跨链桥
│   └── MessageRelay.sol          # 消息中继
├── utils/
│   ├── SafeMath.sol
│   ├── ReentrancyGuard.sol
│   └── Pausable.sol
└── interfaces/
    ├── IValidatorManager.sol
    ├── IStaking.sol
    └── IGovernance.sol
```

---

## 🧪 测试计划

### 单元测试

**测试覆盖**:
| 合约 | 测试用例数 | 覆盖率目标 |
|------|-----------|-----------|
| QAIToken | 50+ | ≥95% |
| ValidatorManager | 80+ | ≥90% |
| QAIStaking | 60+ | ≥90% |
| Governance | 70+ | ≥90% |
| Bridge | 100+ | ≥85% |

**测试框架**:
- Hardhat + Chai + Waffle
- Foundry (模糊测试)
- Slither (静态分析)

---

### 测试场景

**正常场景**:
```
- 质押/解绑流程
- 奖励计算和领取
- 验证者注册/注销
- 治理投票
- 跨链转账
```

**边界场景**:
```
- 最小/最大质押量
- 解锁期边界
- Gas 限制边界
- 并发操作
```

**异常场景**:
```
- 重入攻击
- 权限绕过尝试
- 价格操纵尝试
- 闪电贷攻击
- DoS 攻击
```

---

## 📅 开发计划

### Milestone 1: 核心合约 (4 周)

**Week 1-2**:
- [ ] QAIToken 合约开发
- [ ] 单元测试编写
- [ ] 内部代码审查

**Week 3-4**:
- [ ] ValidatorManager 开发
- [ ] QAIStaking 开发
- [ ] 集成测试

### Milestone 2: 治理合约 (2 周)

**Week 5-6**:
- [ ] Governor 合约开发
- [ ] Timelock 合约开发
- [ ] 治理 UI 集成

### Milestone 3: 跨链桥 (2 周)

**Week 7-8**:
- [ ] CrossChainBridge 开发
- [ ] 消息中继测试
- [ ] 安全审计

### Milestone 4: 审计优化 (2 周)

**Week 9-10**:
- [ ] 外部审计
- [ ] 问题整改
- [ ] 最终测试
- [ ] 主网部署准备

---

**版本**: v1.0
**创建时间**: 2026-03-31 23:22
**状态**: 设计完成，待开发
**下一步**: Milestone 1 启动开发
