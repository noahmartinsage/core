# Quantum AI Chain SDK

量子 AI 公链官方开发工具包，提供 JavaScript/Python/Go 多语言支持。

## 📦 安装

### JavaScript/TypeScript
```bash
npm install @quantum-ai-chain/sdk
```

### Python
```bash
pip install quantum-ai-chain
```

### Go
```bash
go get github.com/quantum-ai-chain/sdk-go
```

## 🚀 快速开始

### JavaScript 示例

```javascript
import { QuantumClient } from '@quantum-ai-chain/sdk';

// 初始化客户端
const client = new QuantumClient({
  network: 'testnet', // 或 'mainnet'
  nodeUrl: 'https://testnet.quantum-ai-chain.org'
});

// 创建钱包
const wallet = await client.wallet.create();
console.log('钱包地址:', wallet.address);
console.log('助记词:', wallet.mnemonic);

// 查询余额
const balance = await client.wallet.getBalance(wallet.address);
console.log('余额:', balance);

// 转账
const tx = await client.wallet.transfer({
  from: wallet.address,
  to: '0x...',
  amount: 100,
  mnemonic: wallet.mnemonic
});
console.log('交易哈希:', tx.hash);

// 质押
const stake = await client.staking.stake({
  address: wallet.address,
  amount: 1000,
  mnemonic: wallet.mnemonic
});
console.log('质押成功:', stake);

// 查询质押收益
const rewards = await client.staking.getRewards(wallet.address);
console.log('待领取收益:', rewards);

// 部署智能合约
const contract = await client.contract.deploy({
  code: '0x...',
  abi: [...],
  args: [],
  mnemonic: wallet.mnemonic
});
console.log('合约地址:', contract.address);

// 调用合约
const result = await client.contract.call({
  contractAddress: contract.address,
  function: 'transfer',
  args: ['0x...', 100],
  mnemonic: wallet.mnemonic
});

// 查询区块
const block = await client.chain.getBlock(1234);
console.log('区块信息:', block);

// 查询交易
const tx = await client.chain.getTransaction('0x...');
console.log('交易详情:', tx);

// AI 管家查询
const aiResponse = await client.ai.ask('我的余额是多少？');
console.log('AI 回复:', aiResponse);
```

### Python 示例

```python
from quantum_ai_chain import QuantumClient

# 初始化客户端
client = QuantumClient(
    network='testnet',
    node_url='https://testnet.quantum-ai-chain.org'
)

# 创建钱包
wallet = client.wallet.create()
print(f'钱包地址：{wallet.address}')
print(f'助记词：{wallet.mnemonic}')

# 查询余额
balance = client.wallet.get_balance(wallet.address)
print(f'余额：{balance}')

# 转账
tx = client.wallet.transfer(
    from_=wallet.address,
    to='0x...',
    amount=100,
    mnemonic=wallet.mnemonic
)
print(f'交易哈希：{tx.hash}')

# 质押
stake = client.staking.stake(
    address=wallet.address,
    amount=1000,
    mnemonic=wallet.mnemonic
)
print(f'质押成功：{stake}')

# 查询区块
block = client.chain.get_block(1234)
print(f'区块信息：{block}')
```

## 📚 API 文档

### Wallet API

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `create()` | - | `Wallet` | 创建新钱包 |
| `import(mnemonic)` | `mnemonic: string` | `Wallet` | 导入钱包 |
| `getBalance(address)` | `address: string` | `number` | 查询余额 |
| `transfer(params)` | `TransferParams` | `Transaction` | 转账 |
| `sign(message)` | `message: string` | `Signature` | 签名消息 |

### Staking API

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `stake(params)` | `StakeParams` | `Stake` | 质押 |
| `unstake(params)` | `UnstakeParams` | `Unstake` | 解押 |
| `claimRewards(params)` | `address: string` | `number` | 领取收益 |
| `getRewards(address)` | `address: string` | `number` | 查询待领取收益 |
| `getStakeInfo(address)` | `address: string` | `StakeInfo` | 查询质押信息 |

### Contract API

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `deploy(params)` | `DeployParams` | `Contract` | 部署合约 |
| `call(params)` | `CallParams` | `any` | 调用合约函数 |
| `verify(address)` | `address: string` | `boolean` | 验证合约 |
| `getContract(address)` | `address: string` | `Contract` | 获取合约信息 |

### Chain API

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `getBlock(height)` | `height: number` | `Block` | 查询区块 |
| `getTransaction(hash)` | `hash: string` | `Transaction` | 查询交易 |
| `getLatestBlock()` | - | `Block` | 查询最新区块 |
| `getTPS()` | - | `number` | 获取当前 TPS |

### AI API

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `ask(question)` | `question: string` | `string` | 向 AI 管家提问 |
| `analyze(address)` | `address: string` | `Analysis` | 分析账户数据 |
| `recommend()` | - | `Recommendation` | 获取投资建议 |

## 🔧 配置选项

```javascript
const client = new QuantumClient({
  // 网络：testnet, mainnet, devnet
  network: 'testnet',
  
  // 节点 URL
  nodeUrl: 'https://testnet.quantum-ai-chain.org',
  
  // 超时时间 (毫秒)
  timeout: 30000,
  
  // 重试次数
  retries: 3,
  
  // API Key (可选，用于高级功能)
  apiKey: 'your-api-key'
});
```

## 🎯 高级功能

### 批量转账

```javascript
const transfers = [
  { to: '0x...', amount: 100 },
  { to: '0x...', amount: 200 },
  { to: '0x...', amount: 300 }
];

const txs = await client.wallet.batchTransfer({
  from: wallet.address,
  transfers: transfers,
  mnemonic: wallet.mnemonic
});

console.log('批量转账完成:', txs.length);
```

### 监听事件

```javascript
// 监听新区块
client.chain.on('block', (block) => {
  console.log('新区块:', block.height);
});

// 监听交易
client.chain.on('transaction', (tx) => {
  console.log('新交易:', tx.hash);
});

// 监听特定地址
client.chain.onAddress(wallet.address, (event) => {
  console.log('地址活动:', event);
});
```

### 离线签名

```javascript
// 创建离线交易
const tx = await client.wallet.createTransaction({
  to: '0x...',
  amount: 100,
  nonce: await client.wallet.getNonce(wallet.address)
});

// 离线签名
const signature = await wallet.sign(tx);

// 广播交易
const result = await client.chain.broadcast(tx, signature);
```

## 📖 更多示例

- [钱包管理示例](./examples/wallet.md)
- [质押挖矿示例](./examples/staking.md)
- [智能合约示例](./examples/contract.md)
- [AI 管家示例](./examples/ai.md)
- [商城支付示例](./examples/payment.md)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License
