# Quantum AI Chain Skills

量子 AI 公链 AI 技能包，供开发者快速集成 AI 能力。

## 📦 安装

```bash
# 通过 ClawHub 安装
clawhub install quantum-ai-chain-skills
```

## 🚀 技能列表

### 1. 钱包管理技能

```javascript
// 技能名称：wallet-manager
// 功能：创建、导入、管理钱包

import { walletManager } from '@quantum-ai-chain/skills';

// 创建钱包
const wallet = await walletManager.create();

// 导入钱包
const wallet = await walletManager.import(mnemonic);

// 查询余额
const balance = await walletManager.getBalance(address);

// 自动备份
await walletManager.backup(wallet, 'encrypted');
```

### 2. 支付技能

```javascript
// 技能名称：payment-processor
// 功能：处理支付、扫码、清算

import { paymentProcessor } from '@quantum-ai-chain/skills';

// 生成支付二维码
const qrCode = await paymentProcessor.generateQR({
  amount: 100,
  currency: 'QAI',
  merchant: '0x...',
  description: '商品购买'
});

// 验证支付
const verified = await paymentProcessor.verify(txHash);

// 自动清算
await paymentProcessor.settle(merchantId);
```

### 3. 推荐系统技能

```javascript
// 技能名称：referral-system
// 功能：用户裂变、推荐奖励、多级分销

import { referralSystem } from '@quantum-ai-chain/skills';

// 生成推荐码
const code = await referralSystem.generateCode(userId);

// 绑定推荐关系
await referralSystem.bind(referrer, referee);

// 计算奖励
const rewards = await referralSystem.calculateRewards(userId);

// 查询团队
const team = await referralSystem.getTeam(userId);
```

### 4. 商城技能

```javascript
// 技能名称：marketplace
// 功能：商品管理、订单处理、NFT 铸造

import { marketplace } from '@quantum-ai-chain/skills';

// 上架商品
const product = await marketplace.listProduct({
  name: '商品名称',
  price: 100,
  nft: true,
  supply: 1000
});

// 购买商品
const order = await marketplace.purchase(productId, buyer);

// 铸造 NFT
const nft = await marketplace.mintNFT(orderId);

// 查询订单
const orders = await marketplace.getOrders(userId);
```

### 5. AI 分析技能

```javascript
// 技能名称：ai-analytics
// 功能：数据分析、风险评估、投资建议

import { aiAnalytics } from '@quantum-ai-chain/skills';

// 账户分析
const analysis = await aiAnalytics.analyzeAccount(address);

// 风险评估
const risk = await aiAnalytics.assessRisk(portfolio);

// 投资建议
const recommendation = await aiAnalytics.recommend(address);

// 市场趋势
const trend = await aiAnalytics.marketTrend();
```

### 6. 智能合约技能

```javascript
// 技能名称：contract-helper
// 功能：合约部署、验证、调用

import { contractHelper } from '@quantum-ai-chain/skills';

// 部署合约
const contract = await contractHelper.deploy({
  code: solidityCode,
  args: [],
  optimize: true
});

// 验证合约
const verified = await contractHelper.verify(contractAddress);

// 安全审计
const audit = await contractHelper.audit(contractAddress);

// 调用合约
const result = await contractHelper.call({
  contract: contractAddress,
  function: 'transfer',
  args: ['0x...', 100]
});
```

## 🎯 组合使用示例

### 电商完整流程

```javascript
import { walletManager, paymentProcessor, marketplace, referralSystem } from '@quantum-ai-chain/skills';

// 1. 创建用户钱包
const buyer = await walletManager.create();

// 2. 生成推荐码 (卖家)
const referralCode = await referralSystem.generateCode(sellerId);

// 3. 绑定推荐关系
await referralSystem.bind(sellerId, buyer.address);

// 4. 浏览商品
const products = await marketplace.listProducts();

// 5. 购买商品
const order = await marketplace.purchase(productId, buyer.address);

// 6. 生成支付二维码
const qrCode = await paymentProcessor.generateQR({
  amount: order.total,
  currency: 'QAI',
  merchant: sellerId,
  orderId: order.id
});

// 7. 用户扫码支付
const payment = await paymentProcessor.scanAndPay(qrCode, buyer);

// 8. 铸造 NFT (如果商品是 NFT)
if (order.isNFT) {
  const nft = await marketplace.mintNFT(order.id);
}

// 9. 计算推荐奖励
const rewards = await referralSystem.calculateRewards(sellerId);

// 10. 自动清算
await paymentProcessor.settle(sellerId);
```

## 📚 API 文档

### WalletManager

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `create()` | - | `Wallet` | 创建钱包 |
| `import(mnemonic)` | `mnemonic: string` | `Wallet` | 导入钱包 |
| `backup(wallet, type)` | `wallet, type` | `Backup` | 备份钱包 |
| `getBalance(address)` | `address: string` | `number` | 查询余额 |

### PaymentProcessor

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `generateQR(params)` | `PaymentParams` | `QRCode` | 生成支付码 |
| `verify(txHash)` | `txHash: string` | `boolean` | 验证支付 |
| `scanAndPay(qr, wallet)` | `QRCode, Wallet` | `Payment` | 扫码支付 |
| `settle(merchantId)` | `merchantId: string` | `Settlement` | 清算 |

### ReferralSystem

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `generateCode(userId)` | `userId: string` | `string` | 生成推荐码 |
| `bind(referrer, referee)` | `string, string` | `Binding` | 绑定关系 |
| `calculateRewards(userId)` | `userId: string` | `Rewards` | 计算奖励 |
| `getTeam(userId)` | `userId: string` | `Team` | 查询团队 |

### Marketplace

| 方法 | 参数 | 返回值 | 描述 |
|------|------|--------|------|
| `listProduct(params)` | `ProductParams` | `Product` | 上架商品 |
| `purchase(productId, buyer)` | `string, string` | `Order` | 购买商品 |
| `mintNFT(orderId)` | `orderId: string` | `NFT` | 铸造 NFT |
| `getOrders(userId)` | `userId: string` | `Order[]` | 查询订单 |

## 🔧 配置

```javascript
import { configure } from '@quantum-ai-chain/skills';

configure({
  network: 'testnet',
  nodeUrl: 'https://testnet.quantum-ai-chain.org',
  apiKey: 'your-api-key',
  features: {
    wallet: true,
    payment: true,
    referral: true,
    marketplace: true,
    analytics: true,
    contract: true
  }
});
```

## 📖 更多示例

- [电商集成示例](./examples/ecommerce.md)
- [支付集成示例](./examples/payment.md)
-推荐系统示例](./examples/referral.md)
- [NFT 商城示例](./examples/nft-marketplace.md)
