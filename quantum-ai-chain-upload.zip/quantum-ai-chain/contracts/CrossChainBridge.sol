// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title CrossChainBridge - 跨链桥合约
 * @notice 支持多链资产跨链转移
 */

contract CrossChainBridge {
    enum ChainId {
        ETHEREUM,
        BSC,
        POLYGON,
        SOLANA,
        QUANTUM_AI
    }
    
    struct LockedAsset {
        address user;
        uint256 amount;
        uint256 timestamp;
        ChainId targetChain;
        bytes32 targetAddress;
        bool claimed;
    }
    
    // 映射：nonce -> LockedAsset
    mapping(uint256 => LockedAsset) public lockedAssets;
    uint256 public nonce;
    
    // 支持的链
    mapping(ChainId => bool) public supportedChains;
    
    // 手续费：百分比 (100 = 1%)
    uint256 public bridgeFee = 50; // 0.5%
    
    // 事件
    event AssetLocked(
        uint256 indexed nonce,
        address indexed user,
        uint256 amount,
        ChainId targetChain,
        bytes32 targetAddress
    );
    
    event AssetUnlocked(
        uint256 indexed nonce,
        address indexed user,
        uint256 amount,
        ChainId sourceChain
    );
    
    constructor() {
        supportedChains[ChainId.ETHEREUM] = true;
        supportedChains[ChainId.BSC] = true;
        supportedChains[ChainId.POLYGON] = true;
        supportedChains[ChainId.SOLANA] = true;
        supportedChains[ChainId.QUANTUM_AI] = true;
    }
    
    /**
     * @notice 锁定资产进行跨链
     * @param targetChain 目标链 ID
     * @param targetAddress 目标链接收地址 (bytes32 格式)
     */
    function lockAsset(
        ChainId targetChain,
        bytes32 targetAddress
    ) external payable returns (uint256) {
        require(supportedChains[targetChain], "Unsupported chain");
        require(msg.value > 0, "Amount must be > 0");
        
        // 计算手续费
        uint256 fee = (msg.value * bridgeFee) / 10000;
        uint256 actualAmount = msg.value - fee;
        
        // 生成唯一 nonce
        nonce++;
        
        // 锁定资产
        lockedAssets[nonce] = LockedAsset({
            user: msg.sender,
            amount: actualAmount,
            timestamp: block.timestamp,
            targetChain: targetChain,
            targetAddress: targetAddress,
            claimed: false
        });
        
        emit AssetLocked(nonce, msg.sender, actualAmount, targetChain, targetAddress);
        
        return nonce;
    }
    
    /**
     * @notice 在目标链解锁资产
     * @param assetNonce 资产 nonce
     * @param recipient 接收地址
     */
    function unlockAsset(uint256 assetNonce, address recipient) external {
        LockedAsset storage asset = lockedAssets[assetNonce];
        
        require(!asset.claimed, "Already claimed");
        require(asset.targetChain == ChainId.QUANTUM_AI, "Not for this chain");
        require(block.timestamp >= asset.timestamp + 300, "Lock period not ended"); // 5 分钟锁定期
        
        asset.claimed = true;
        
        (bool success, ) = payable(recipient).call{value: asset.amount}("");
        require(success, "Transfer failed");
        
        emit AssetUnlocked(assetNonce, recipient, asset.amount, asset.targetChain);
    }
    
    /**
     * @notice 添加支持的链
     */
    function addSupportedChain(ChainId chainId) external {
        supportedChains[chainId] = true;
    }
    
    /**
     * @notice 设置跨链手续费
     */
    function setBridgeFee(uint256 newFee) external {
        require(newFee <= 100, "Fee too high"); // 最大 1%
        bridgeFee = newFee;
    }
    
    /**
     * @notice 提取手续费
     */
    function withdrawFees(address payable recipient) external {
        uint256 balance = address(this).balance;
        (bool success, ) = recipient.call{value: balance}("");
        require(success, "Withdraw failed");
    }
}
