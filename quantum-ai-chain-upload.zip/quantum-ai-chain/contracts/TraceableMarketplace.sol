// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title TraceableMarketplace - 可溯源商城合约
 * @notice 一物一证一权一链一溯源，NFT 商品 + 实物对应
 */

contract TraceableMarketplace {
    // 商品结构
    struct Product {
        uint256 id;
        string name;
        string description;
        uint256 price;
        uint256 supply;
        uint256 sold;
        address seller;
        bool isNFT;
        bool isActive;
        bytes32 ipfsHash; // IPFS 存储的商品信息
    }
    
    // 溯源信息结构
    struct TraceInfo {
        uint256 productId;
        uint256 tokenId;
        string origin; // 原产地
        string manufacturer; // 生产商
        uint256 productionDate; // 生产日期
        uint256 qualityCheckDate; // 质检日期
        string[] transportRecords; // 运输记录
        string[] ownershipHistory; // 所有权历史
    }
    
    // NFT 结构 (ERC721 简化版)
    struct NFT {
        uint256 tokenId;
        uint256 productId;
        address owner;
        string metadata;
        bool exists;
    }
    
    // 订单结构
    struct Order {
        uint256 id;
        uint256 productId;
        uint256 tokenId;
        address buyer;
        address seller;
        uint256 price;
        uint256 timestamp;
        bool completed;
        bool reviewed;
    }
    
    // 版权信息结构
    struct Copyright {
        uint256 productId;
        string copyrightId;
        address owner;
        uint256 registrationDate;
        bool isActive;
        uint256 royaltyRate; // 版税率 (100 = 1%)
    }
    
    // 映射
    mapping(uint256 => Product) public products;
    mapping(uint256 => TraceInfo) public traceInfos;
    mapping(uint256 => NFT) public nfts;
    mapping(uint256 => Order) public orders;
    mapping(uint256 => Copyright) public copyrights;
    mapping(address => uint256[]) public sellerProducts;
    mapping(address => uint256[]) public buyerOrders;
    mapping(uint256 => uint256[]) public productNFTs;
    
    // 计数器
    uint256 public productCounter;
    uint256 public nftCounter;
    uint256 public orderCounter;
    
    // 平台手续费：百分比 (100 = 1%)
    uint256 public platformFee = 200; // 2%
    
    // 事件
    event ProductListed(uint256 indexed productId, string name, uint256 price, bool isNFT);
    event ProductSold(uint256 indexed productId, address buyer, uint256 price);
    event NFTMinted(uint256 indexed tokenId, uint256 productId, address owner);
    event NFTransferred(uint256 indexed tokenId, address from, address to);
    event OrderCompleted(uint256 indexed orderId, uint256 productId, address buyer);
    event CopyrightRegistered(uint256 indexed productId, string copyrightId, address owner);
    event TraceInfoAdded(uint256 indexed productId, string origin);
    
    /**
     * @notice 上架商品
     */
    function listProduct(
        string memory name,
        string memory description,
        uint256 price,
        uint256 supply,
        bool isNFT,
        bytes32 ipfsHash
    ) external returns (uint256) {
        productCounter++;
        
        products[productCounter] = Product({
            id: productCounter,
            name: name,
            description: description,
            price: price,
            supply: supply,
            sold: 0,
            seller: msg.sender,
            isNFT: isNFT,
            isActive: true,
            ipfsHash: ipfsHash
        });
        
        sellerProducts[msg.sender].push(productCounter);
        
        emit ProductListed(productCounter, name, price, isNFT);
        return productCounter;
    }
    
    /**
     * @notice 购买商品
     */
    function buyProduct(uint256 productId) external payable returns (uint256) {
        Product storage product = products[productId];
        require(product.isActive, "Product not active");
        require(product.sold < product.supply, "Out of stock");
        require(msg.value >= product.price, "Insufficient payment");
        
        // 更新销售数据
        product.sold++;
        
        // 计算手续费
        uint256 fee = (product.price * platformFee) / 10000;
        uint256 sellerAmount = product.price - fee;
        
        // 创建订单
        orderCounter++;
        orders[orderCounter] = Order({
            id: orderCounter,
            productId: productId,
            tokenId: 0,
            buyer: msg.sender,
            seller: product.seller,
            price: product.price,
            timestamp: block.timestamp,
            completed: true,
            reviewed: false
        });
        
        buyerOrders[msg.sender].push(orderCounter);
        
        // 如果是 NFT 商品，铸造 NFT
        if (product.isNFT) {
            nftCounter++;
            nfts[nftCounter] = NFT({
                tokenId: nftCounter,
                productId: productId,
                owner: msg.sender,
                metadata: product.description,
                exists: true
            });
            
            orders[orderCounter].tokenId = nftCounter;
            productNFTs[productId].push(nftCounter);
            
            emit NFTMinted(nftCounter, productId, msg.sender);
        }
        
        // 支付给卖家
        (bool success, ) = payable(product.seller).call{value: sellerAmount}("");
        require(success, "Transfer to seller failed");
        
        emit ProductSold(productId, msg.sender, product.price);
        emit OrderCompleted(orderCounter, productId, msg.sender);
        
        return orderCounter;
    }
    
    /**
     * @notice 添加溯源信息
     */
    function addTraceInfo(
        uint256 productId,
        string memory origin,
        string memory manufacturer,
        uint256 productionDate,
        uint256 qualityCheckDate
    ) external {
        Product storage product = products[productId];
        require(msg.sender == product.seller, "Only seller");
        
        traceInfos[productId] = TraceInfo({
            productId: productId,
            tokenId: 0,
            origin: origin,
            manufacturer: manufacturer,
            productionDate: productionDate,
            qualityCheckDate: qualityCheckDate,
            transportRecords: new string[](0),
            ownershipHistory: new string[](0)
        });
        
        emit TraceInfoAdded(productId, origin);
    }
    
    /**
     * @notice 注册版权
     */
    function registerCopyright(
        uint256 productId,
        string memory copyrightId,
        uint256 royaltyRate
    ) external returns (uint256) {
        Product storage product = products[productId];
        require(msg.sender == product.seller, "Only seller");
        
        copyrights[productId] = Copyright({
            productId: productId,
            copyrightId: copyrightId,
            owner: msg.sender,
            registrationDate: block.timestamp,
            isActive: true,
            royaltyRate: royaltyRate
        });
        
        emit CopyrightRegistered(productId, copyrightId, msg.sender);
        return productId;
    }
    
    /**
     * @notice NFT 转赠
     */
    function transferNFT(uint256 tokenId, address to) external {
        NFT storage nft = nfts[tokenId];
        require(nft.exists, "NFT does not exist");
        require(msg.sender == nft.owner, "Not owner");
        
        address from = nft.owner;
        nft.owner = to;
        
        // 更新溯源信息
        TraceInfo storage trace = traceInfos[nft.productId];
        trace.ownershipHistory = _addToStringArray(trace.ownershipHistory, 
            string(abi.encodePacked(from, " -> ", to, " @ ", block.timestamp)));
        
        emit NFTransferred(tokenId, from, to);
    }
    
    /**
     * @notice 获取商品信息
     */
    function getProductInfo(uint256 productId) external view returns (Product memory) {
        return products[productId];
    }
    
    /**
     * @notice 获取溯源信息
     */
    function getTraceInfo(uint256 productId) external view returns (TraceInfo memory) {
        return traceInfos[productId];
    }
    
    /**
     * @notice 获取 NFT 信息
     */
    function getNFTInfo(uint256 tokenId) external view returns (NFT memory) {
        return nfts[tokenId];
    }
    
    // 内部函数：添加字符串到数组
    function _addToStringArray(string[] storage array, string memory value) 
        internal returns (string[] storage) 
    {
        array = new string[](array.length + 1);
        array[array.length - 1] = value;
        return array;
    }
}
