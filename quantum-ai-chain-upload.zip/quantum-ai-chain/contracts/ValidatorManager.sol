// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title ValidatorManager - 验证者管理合约
 * @notice 管理量子 AI 公链的验证者节点
 */

contract ValidatorManager {
    struct Validator {
        address operator;
        uint256 stake;
        bool isActive;
        uint256 rewards;
        uint256 lastHeartbeat;
    }
    
    mapping(address => Validator) public validators;
    address[] public validatorList;
    uint256 public constant MIN_STAKE = 10_000 * 10**18; // 10,000 QAI
    
    event ValidatorRegistered(address indexed operator, uint256 stake);
    event ValidatorRemoved(address indexed operator);
    event RewardsDistributed(address indexed operator, uint256 amount);
    
    function registerValidator() external payable {
        require(msg.value >= MIN_STAKE, "Insufficient stake");
        require(!validators[msg.sender].isActive, "Already registered");
        
        validators[msg.sender] = Validator({
            operator: msg.sender,
            stake: msg.value,
            isActive: true,
            rewards: 0,
            lastHeartbeat: block.timestamp
        });
        
        validatorList.push(msg.sender);
        emit ValidatorRegistered(msg.sender, msg.value);
    }
    
    function removeValidator() external {
        require(validators[msg.sender].isActive, "Not a validator");
        validators[msg.sender].isActive = false;
        emit ValidatorRemoved(msg.sender);
    }
    
    function updateHeartbeat() external {
        require(validators[msg.sender].isActive, "Not a validator");
        validators[msg.sender].lastHeartbeat = block.timestamp;
    }
    
    function distributeRewards(address validator, uint256 amount) external {
        require(validators[validator].isActive, "Not a validator");
        validators[validator].rewards += amount;
        emit RewardsDistributed(validator, amount);
    }
    
    function getValidatorCount() external view returns (uint256) {
        return validatorList.length;
    }
}
