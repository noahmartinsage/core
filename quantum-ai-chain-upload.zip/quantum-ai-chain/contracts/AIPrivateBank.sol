// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title AIPrivateBank - AI 私人银行合约
 * @notice 提供 AI 驱动的理财、支付、借贷、保险功能
 */

contract AIPrivateBank {
    // 用户账户结构
    struct Account {
        uint256 balance;
        uint256 staked;
        uint256 borrowed;
        uint256 creditScore;
        uint256 lastActivity;
        bool isActive;
    }
    
    // 理财产品结构
    struct WealthProduct {
        uint256 id;
        string name;
        uint256 apy; // 年化收益率 (100 = 1%)
        uint256 minAmount;
        uint256 lockPeriod; // 锁定期 (天)
        uint256 totalStaked;
        bool isActive;
    }
    
    // 贷款结构
    struct Loan {
        uint256 id;
        address borrower;
        uint256 principal;
        uint256 interest;
        uint256 dueDate;
        bool repaid;
        bool defaulted;
    }
    
    // 保险单结构
    struct InsurancePolicy {
        uint256 id;
        address holder;
        string policyType;
        uint256 coverage;
        uint256 premium;
        uint256 startDate;
        uint256 endDate;
        bool active;
        bool claimed;
    }
    
    // 映射
    mapping(address => Account) public accounts;
    mapping(uint256 => WealthProduct) public wealthProducts;
    mapping(uint256 => Loan) public loans;
    mapping(uint256 => InsurancePolicy) public insurancePolicies;
    mapping(address => uint256[]) public userStakes;
    mapping(address => uint256[]) public userLoans;
    
    // 计数器
    uint256 public productCounter;
    uint256 public loanCounter;
    uint256 public policyCounter;
    
    // AI 管家地址
    address public aiAgent;
    
    // 事件
    event AccountCreated(address indexed user);
    event WealthProductCreated(uint256 indexed productId, string name, uint256 apy);
    event StakeDeposited(address indexed user, uint256 productId, uint256 amount);
    event StakeWithdrawn(address indexed user, uint256 productId, uint256 amount, uint256 reward);
    event LoanCreated(uint256 indexed loanId, address borrower, uint256 amount);
    event LoanRepaid(uint256 indexed loanId, address borrower, uint256 amount);
    event InsurancePurchased(uint256 indexed policyId, address holder, string policyType);
    event InsuranceClaimed(uint256 indexed policyId, address holder, uint256 amount);
    
    modifier onlyAI() {
        require(msg.sender == aiAgent, "Only AI agent");
        _;
    }
    
    constructor() {
        aiAgent = msg.sender;
        productCounter = 0;
        loanCounter = 0;
        policyCounter = 0;
    }
    
    /**
     * @notice 创建账户
     */
    function createAccount() external {
        require(!accounts[msg.sender].isActive, "Account already exists");
        
        accounts[msg.sender] = Account({
            balance: 0,
            staked: 0,
            borrowed: 0,
            creditScore: 650, // 初始信用分
            lastActivity: block.timestamp,
            isActive: true
        });
        
        emit AccountCreated(msg.sender);
    }
    
    /**
     * @notice 创建理财产品
     */
    function createWealthProduct(
        string memory name,
        uint256 apy,
        uint256 minAmount,
        uint256 lockPeriod
    ) external onlyAI returns (uint256) {
        productCounter++;
        
        wealthProducts[productCounter] = WealthProduct({
            id: productCounter,
            name: name,
            apy: apy,
            minAmount: minAmount,
            lockPeriod: lockPeriod,
            totalStaked: 0,
            isActive: true
        });
        
        emit WealthProductCreated(productCounter, name, apy);
        return productCounter;
    }
    
    /**
     * @notice 存入理财
     */
    function depositWealth(uint256 productId, uint256 amount) external payable {
        WealthProduct storage product = wealthProducts[productId];
        require(product.isActive, "Product not active");
        require(amount >= product.minAmount, "Below minimum");
        require(msg.value == amount, "Amount mismatch");
        
        product.totalStaked += amount;
        accounts[msg.sender].balance += amount;
        accounts[msg.sender].staked += amount;
        userStakes[msg.sender].push(productId);
        
        emit StakeDeposited(msg.sender, productId, amount);
    }
    
    /**
     * @notice 提取理财 + 收益
     */
    function withdrawWealth(uint256 productId) external {
        WealthProduct storage product = wealthProducts[productId];
        require(product.isActive, "Product not active");
        
        uint256 stakeAmount = accounts[msg.sender].staked;
        require(stakeAmount > 0, "No stake");
        
        // 计算收益
        uint256 reward = (stakeAmount * product.apy * product.lockPeriod) / (10000 * 365);
        uint256 totalAmount = stakeAmount + reward;
        
        product.totalStaked -= stakeAmount;
        accounts[msg.sender].staked -= stakeAmount;
        
        (bool success, ) = payable(msg.sender).call{value: totalAmount}("");
        require(success, "Transfer failed");
        
        emit StakeWithdrawn(msg.sender, productId, stakeAmount, reward);
    }
    
    /**
     * @notice 申请贷款
     */
    function applyLoan(uint256 amount, uint256 duration) external returns (uint256) {
        Account storage account = accounts[msg.sender];
        require(account.isActive, "No account");
        require(account.creditScore >= 600, "Credit score too low");
        
        // 根据信用分计算额度和利率
        uint256 maxLoan = (account.creditScore * 10) * 1e18; // 信用分*10
        require(amount <= maxLoan, "Exceeds credit limit");
        
        uint256 interestRate = 1000 - (account.creditScore / 10); // 10% - 信用分/10
        uint256 interest = (amount * interestRate * duration) / (10000 * 30);
        
        loanCounter++;
        loans[loanCounter] = Loan({
            id: loanCounter,
            borrower: msg.sender,
            principal: amount,
            interest: interest,
            dueDate: block.timestamp + (duration * 1 days),
            repaid: false,
            defaulted: false
        });
        
        account.borrowed += amount;
        userLoans[msg.sender].push(loanCounter);
        
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        require(success, "Transfer failed");
        
        emit LoanCreated(loanCounter, msg.sender, amount);
        return loanCounter;
    }
    
    /**
     * @notice 购买保险
     */
    function purchaseInsurance(
        string memory policyType,
        uint256 coverage,
        uint256 duration
    ) external payable returns (uint256) {
        require(msg.value > 0, "Premium must be > 0");
        
        policyCounter++;
        
        insurancePolicies[policyCounter] = InsurancePolicy({
            id: policyCounter,
            holder: msg.sender,
            policyType: policyType,
            coverage: coverage,
            premium: msg.value,
            startDate: block.timestamp,
            endDate: block.timestamp + (duration * 1 days),
            active: true,
            claimed: false
        });
        
        emit InsurancePurchased(policyCounter, msg.sender, policyType);
        return policyCounter;
    }
    
    /**
     * @notice AI 评估信用分
     */
    function aiEvaluateCredit(address user) external onlyAI {
        Account storage account = accounts[user];
        require(account.isActive, "No account");
        
        // AI 根据交易历史、还款记录等评估信用分
        // 这里简化实现
        uint256 newScore = account.creditScore;
        
        if (account.borrowed == 0) {
            newScore += 10; // 无贷款，加分
        }
        
        if (newScore > 850) newScore = 850;
        if (newScore < 300) newScore = 300;
        
        account.creditScore = newScore;
        account.lastActivity = block.timestamp;
    }
    
    /**
     * @notice 获取账户信息
     */
    function getAccountInfo(address user) external view returns (Account memory) {
        return accounts[user];
    }
}
