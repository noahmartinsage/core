// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/**
 * @title Staking - QAI 质押合约
 * @notice 用户质押 QAI 代币获得奖励
 */

contract Staking {
    IERC20 public qaiToken;
    
    struct Stake {
        uint256 amount;
        uint256 rewards;
        uint256 lastUpdateTime;
        uint256 unlockTime;
    }
    
    mapping(address => Stake) public stakes;
    uint256 public rewardRate = 100; // 每秒奖励 (可调整)
    uint256 public constant UNLOCK_PERIOD = 7 days;
    
    event Staked(address indexed user, uint256 amount);
    event Unstaked(address indexed user, uint256 amount);
    event RewardsClaimed(address indexed user, uint256 amount);
    
    constructor(address _qaiToken) {
        qaiToken = IERC20(_qaiToken);
    }
    
    function stake(uint256 amount) external {
        require(amount > 0, "Amount must be > 0");
        _updateReward(msg.sender);
        
        stakes[msg.sender].amount += amount;
        stakes[msg.sender].unlockTime = block.timestamp + UNLOCK_PERIOD;
        
        qaiToken.transferFrom(msg.sender, address(this), amount);
        emit Staked(msg.sender, amount);
    }
    
    function unstake(uint256 amount) external {
        require(stakes[msg.sender].amount >= amount, "Insufficient stake");
        require(block.timestamp >= stakes[msg.sender].unlockTime, "Still locked");
        
        _updateReward(msg.sender);
        stakes[msg.sender].amount -= amount;
        
        qaiToken.transfer(msg.sender, amount);
        emit Unstaked(msg.sender, amount);
    }
    
    function claimRewards() external {
        _updateReward(msg.sender);
        uint256 rewards = stakes[msg.sender].rewards;
        require(rewards > 0, "No rewards");
        
        stakes[msg.sender].rewards = 0;
        qaiToken.transfer(msg.sender, rewards);
        emit RewardsClaimed(msg.sender, rewards);
    }
    
    function _updateReward(address user) internal {
        Stake storage stake = stakes[user];
        uint256 timeElapsed = block.timestamp - stake.lastUpdateTime;
        uint256 reward = (stake.amount * rewardRate * timeElapsed) / 1e18;
        stake.rewards += reward;
        stake.lastUpdateTime = block.timestamp;
    }
}

interface IERC20 {
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    function transfer(address recipient, uint256 amount) external returns (bool);
}
