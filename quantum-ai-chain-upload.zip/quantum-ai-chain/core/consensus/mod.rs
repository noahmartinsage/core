//! 量子 AI 公链 - 共识模块核心实现
//! 
//! 包含：
//! - 验证者管理
//! - 选举算法
//! - 区块结构
//! - 区块生产
//! - 最终性确认

use std::collections::HashMap;
use sha2::{Sha256, Digest};
use serde::{Serialize, Deserialize};
use chrono::{Utc, DateTime};

/// 验证者结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Validator {
    pub address: String,
    pub stake: u128,
    pub is_active: bool,
    pub rewards: u128,
    pub last_heartbeat: DateTime<Utc>,
    pub public_key: String,
}

/// 区块结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Block {
    pub height: u64,
    pub hash: String,
    pub parent_hash: String,
    pub timestamp: DateTime<Utc>,
    pub producer: String,
    pub transactions: Vec<Transaction>,
    pub state_root: String,
    pub signatures: Vec<ValidatorSignature>,
}

/// 交易结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub hash: String,
    pub from: String,
    pub to: String,
    pub amount: u128,
    pub timestamp: DateTime<Utc>,
    pub signature: String,
    pub data: Option<String>,
}

/// 验证者签名
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidatorSignature {
    pub validator: String,
    pub signature: String,
    pub block_hash: String,
}

/// 共识状态
pub struct ConsensusState {
    pub validators: HashMap<String, Validator>,
    pub current_height: u64,
    pub current_producer: String,
    pub pending_transactions: Vec<Transaction>,
    pub min_stake: u128,
    pub max_validators: usize,
}

impl ConsensusState {
    /// 创建新的共识状态
    pub fn new() -> Self {
        ConsensusState {
            validators: HashMap::new(),
            current_height: 0,
            current_producer: String::new(),
            pending_transactions: Vec::new(),
            min_stake: 10_000 * 10u128.pow(18), // 10,000 QAI
            max_validators: 21,
        }
    }
    
    /// 注册验证者
    pub fn register_validator(&mut self, validator: Validator) -> Result<(), String> {
        if validator.stake < self.min_stake {
            return Err("Insufficient stake".to_string());
        }
        
        if self.validators.len() >= self.max_validators {
            return Err("Max validators reached".to_string());
        }
        
        self.validators.insert(validator.address.clone(), validator);
        Ok(())
    }
    
    /// 选举区块生产者 (基于质押量和随机性)
    pub fn elect_producer(&mut self) -> Option<String> {
        if self.validators.is_empty() {
            return None;
        }
        
        // 计算总质押量
        let total_stake: u128 = self.validators.values()
            .filter(|v| v.is_active)
            .map(|v| v.stake)
            .sum();
        
        if total_stake == 0 {
            return None;
        }
        
        // 加权随机选择
        let mut random = (Utc::now().timestamp_nanos() as u128) % total_stake;
        
        for (address, validator) in &self.validators {
            if !validator.is_active {
                continue;
            }
            
            if random < validator.stake {
                self.current_producer = address.clone();
                return Some(address.clone());
            }
            
            random -= validator.stake;
        }
        
        // 返回质押量最高的验证者
        self.validators.iter()
            .filter(|(_, v)| v.is_active)
            .max_by_key(|(_, v)| v.stake)
            .map(|(addr, _)| addr.clone())
    }
    
    /// 生产新区块
    pub fn produce_block(&mut self) -> Option<Block> {
        let producer = self.elect_producer()?;
        
        if self.pending_transactions.is_empty() {
            return None;
        }
        
        self.current_height += 1;
        
        // 创建区块
        let transactions = self.pending_transactions.clone();
        self.pending_transactions.clear();
        
        let block = Block {
            height: self.current_height,
            hash: self.calculate_block_hash(self.current_height, &transactions),
            parent_hash: self.get_parent_hash(),
            timestamp: Utc::now(),
            producer: producer.clone(),
            transactions,
            state_root: self.calculate_state_root(),
            signatures: Vec::new(),
        };
        
        Some(block)
    }
    
    /// 验证区块
    pub fn validate_block(&self, block: &Block) -> bool {
        // 验证高度
        if block.height != self.current_height + 1 {
            return false;
        }
        
        // 验证父哈希
        if block.parent_hash != self.get_parent_hash() {
            return false;
        }
        
        // 验证时间戳
        if block.timestamp < Utc::now() - chrono::Duration::seconds(10) {
            return false;
        }
        
        // 验证交易
        for tx in &block.transactions {
            if !self.validate_transaction(tx) {
                return false;
            }
        }
        
        // 验证签名数量 (需要 2/3 多数)
        let required_signatures = (self.validators.len() * 2 + 2) / 3;
        if block.signatures.len() < required_signatures {
            return false;
        }
        
        true
    }
    
    /// 验证交易
    fn validate_transaction(&self, tx: &Transaction) -> bool {
        // 验证签名
        // 验证余额
        // 验证 nonce
        // (简化实现，实际需完整验证)
        !tx.from.is_empty() && !tx.to.is_empty() && tx.amount > 0
    }
    
    /// 计算区块哈希
    fn calculate_block_hash(&self, height: u64, transactions: &[Transaction]) -> String {
        let mut hasher = Sha256::new();
        hasher.update(height.to_be_bytes());
        hasher.update(Utc::now().timestamp_nanos().to_be_bytes());
        
        for tx in transactions {
            hasher.update(tx.hash.as_bytes());
        }
        
        let result = hasher.finalize();
        format!("{:x}", result)
    }
    
    /// 获取父区块哈希
    fn get_parent_hash(&self) -> String {
        if self.current_height == 0 {
            return "genesis".to_string();
        }
        
        // 实际应从存储中获取
        format!("block_{}", self.current_height - 1)
    }
    
    /// 计算状态根
    fn calculate_state_root(&self) -> String {
        let mut hasher = Sha256::new();
        for (address, validator) in &self.validators {
            hasher.update(address.as_bytes());
            hasher.update(validator.stake.to_be_bytes());
        }
        
        let result = hasher.finalize();
        format!("{:x}", result)
    }
    
    /// 添加交易到待处理池
    pub fn add_transaction(&mut self, tx: Transaction) {
        self.pending_transactions.push(tx);
    }
    
    /// 更新验证者心跳
    pub fn update_heartbeat(&mut self, address: &str) {
        if let Some(validator) = self.validators.get_mut(address) {
            validator.last_heartbeat = Utc::now();
        }
    }
    
    /// 分发奖励
    pub fn distribute_rewards(&mut self, block_height: u64) {
        let reward_per_block = 10 * 10u128.pow(18); // 10 QAI
        
        if let Some(validator) = self.validators.get_mut(&self.current_producer) {
            validator.rewards += reward_per_block;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_register_validator() {
        let mut state = ConsensusState::new();
        
        let validator = Validator {
            address: "validator1".to_string(),
            stake: 10_000 * 10u128.pow(18),
            is_active: true,
            rewards: 0,
            last_heartbeat: Utc::now(),
            public_key: "pubkey1".to_string(),
        };
        
        assert!(state.register_validator(validator).is_ok());
        assert_eq!(state.validators.len(), 1);
    }
    
    #[test]
    fn test_elect_producer() {
        let mut state = ConsensusState::new();
        
        // 添加多个验证者
        for i in 0..5 {
            let validator = Validator {
                address: format!("validator{}", i),
                stake: (10_000 + i * 1000) * 10u128.pow(18),
                is_active: true,
                rewards: 0,
                last_heartbeat: Utc::now(),
                public_key: format!("pubkey{}", i),
            };
            state.register_validator(validator).unwrap();
        }
        
        let producer = state.elect_producer();
        assert!(producer.is_some());
    }
}
