#!/usr/bin/env python3
"""
量子 AI 公链 - 后端 API 服务
提供完整的 RESTful API，支持钱包、理财、借贷、商城、跨链等功能
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from datetime import datetime, timedelta
import sqlite3
import hashlib
import json
import os
import uuid
from functools import wraps

app = Flask(__name__)
CORS(app)

# 数据库配置
DB_PATH = os.path.join(os.path.dirname(__file__), 'quantum_chain.db')

# ============ 数据库初始化 ============

def init_db():
    """初始化数据库"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 用户表
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            address TEXT UNIQUE NOT NULL,
            balance REAL DEFAULT 10000.0,
            credit_score INTEGER DEFAULT 720,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 理财产品表
    c.execute('''
        CREATE TABLE IF NOT EXISTS wealth_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            apy REAL NOT NULL,
            min_amount REAL NOT NULL,
            lock_period INTEGER NOT NULL,
            total_staked REAL DEFAULT 0,
            is_active BOOLEAN DEFAULT 1
        )
    ''')
    
    # 用户理财记录表
    c.execute('''
        CREATE TABLE IF NOT EXISTS user_stakes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            product_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_date TIMESTAMP,
            reward REAL DEFAULT 0,
            status TEXT DEFAULT 'active',
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES wealth_products(id)
        )
    ''')
    
    # 贷款表
    c.execute('''
        CREATE TABLE IF NOT EXISTS loans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            principal REAL NOT NULL,
            interest REAL NOT NULL,
            due_date TIMESTAMP NOT NULL,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # 商品表
    c.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            supply INTEGER NOT NULL,
            sold INTEGER DEFAULT 0,
            is_nft BOOLEAN DEFAULT 0,
            ipfs_hash TEXT,
            is_active BOOLEAN DEFAULT 1
        )
    ''')
    
    # 订单表
    c.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            product_id INTEGER NOT NULL,
            price REAL NOT NULL,
            status TEXT DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        )
    ''')
    
    # NFT 表
    c.execute('''
        CREATE TABLE IF NOT EXISTS nfts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_id TEXT UNIQUE NOT NULL,
            product_id INTEGER NOT NULL,
            owner_id TEXT NOT NULL,
            metadata TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id),
            FOREIGN KEY (owner_id) REFERENCES users(id)
        )
    ''')
    
    # 跨链交易表
    c.execute('''
        CREATE TABLE IF NOT EXISTS bridge_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            source_chain TEXT NOT NULL,
            target_chain TEXT NOT NULL,
            amount REAL NOT NULL,
            fee REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # 治理提案表
    c.execute('''
        CREATE TABLE IF NOT EXISTS proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            for_votes INTEGER DEFAULT 0,
            against_votes INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_date TIMESTAMP NOT NULL
        )
    ''')
    
    # 投票记录表
    c.execute('''
        CREATE TABLE IF NOT EXISTS votes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            proposal_id INTEGER NOT NULL,
            support BOOLEAN NOT NULL,
            voting_power INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (proposal_id) REFERENCES proposals(id)
        )
    ''')
    
    # 插入初始数据
    c.execute("SELECT COUNT(*) FROM wealth_products")
    if c.fetchone()[0] == 0:
        # 插入理财产品
        c.execute("INSERT INTO wealth_products (name, apy, min_amount, lock_period) VALUES (?, ?, ?, ?)",
                  ('稳健理财 30 天', 8.0, 100, 30))
        c.execute("INSERT INTO wealth_products (name, apy, min_amount, lock_period) VALUES (?, ?, ?, ?)",
                  ('进取理财 90 天', 15.0, 500, 90))
        c.execute("INSERT INTO wealth_products (name, apy, min_amount, lock_period) VALUES (?, ?, ?, ?)",
                  ('AI 量化策略', 20.0, 1000, 0))
        
        # 插入商品
        c.execute("INSERT INTO products (name, description, price, supply, is_nft, ipfs_hash) VALUES (?, ?, ?, ?, ?, ?)",
                  ('量子 AI 公链创世 NFT', '限量版创世 NFT，持有者享受生态分红', 100, 10000, 1, 'QmX1Y2Z3'))
        c.execute("INSERT INTO products (name, description, price, supply, is_nft, ipfs_hash) VALUES (?, ?, ?, ?, ?, ?)",
                  ('AI 智能体设计稿', 'AI 智能体原始设计稿 NFT', 50, 1000, 1, 'QmA4B5C6'))
        c.execute("INSERT INTO products (name, description, price, supply, is_nft, ipfs_hash) VALUES (?, ?, ?, ?, ?, ?)",
                  ('测试网纪念 T 恤', '测试网纪念 T 恤 + NFT 版权证书', 10, 5000, 0, 'QmD7E8F9'))
        
        # 插入治理提案
        c.execute("INSERT INTO proposals (title, description, end_date) VALUES (?, ?, ?)",
                  ('增加生态基金预算', '建议将生态基金从 30% 提升到 35%，以加速生态建设',
                   datetime.now() + timedelta(days=7)))
        c.execute("INSERT INTO proposals (title, description, end_date) VALUES (?, ?, ?)",
                  ('与 BSC 建立跨链桥', '建议与 Binance Smart Chain 建立官方跨链桥，手续费 0.3%',
                   datetime.now() + timedelta(days=7)))
    
    conn.commit()
    conn.close()
    print("✅ 数据库初始化完成")

# ============ 辅助函数 ============

def get_db():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def generate_address():
    """生成钱包地址"""
    return '0x' + hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()[:40]

def auth_required(f):
    """认证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        # 简化认证，实际项目应使用 JWT
        user_id = request.headers.get('X-User-ID')
        if not user_id:
            # 自动创建用户
            user_id = str(uuid.uuid4())
            address = generate_address()
            conn = get_db()
            conn.execute("INSERT OR IGNORE INTO users (id, address) VALUES (?, ?)", (user_id, address))
            conn.commit()
            conn.close()
        return f(*args, **kwargs)
    return decorated

# ============ API 路由 ============

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查"""
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

# ----- 钱包 API -----

@app.route('/api/wallet', methods=['GET'])
@auth_required
def get_wallet():
    """获取钱包信息"""
    user_id = request.headers.get('X-User-ID')
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'address': user['address'],
        'balance': user['balance'],
        'credit_score': user['credit_score'],
        'created_at': user['created_at']
    })

@app.route('/api/wallet/deposit', methods=['POST'])
@auth_required
def deposit():
    """充值"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    amount = data.get('amount', 0)
    
    if amount <= 0:
        return jsonify({'error': 'Invalid amount'}), 400
    
    conn = get_db()
    conn.execute("UPDATE users SET balance = balance + ? WHERE id = ?", (amount, user_id))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'充值成功 {amount} QAI',
        'new_balance': get_wallet().__wrapped__().json['balance'] + amount
    })

@app.route('/api/wallet/withdraw', methods=['POST'])
@auth_required
def withdraw():
    """提现"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    amount = data.get('amount', 0)
    
    conn = get_db()
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    
    if not user or user['balance'] < amount:
        conn.close()
        return jsonify({'error': 'Insufficient balance'}), 400
    
    conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (amount, user_id))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'提现成功 {amount} QAI'
    })

# ----- 理财 API -----

@app.route('/api/wealth/products', methods=['GET'])
def get_wealth_products():
    """获取理财产品列表"""
    conn = get_db()
    products = conn.execute("SELECT * FROM wealth_products WHERE is_active = 1").fetchall()
    conn.close()
    
    return jsonify([{
        'id': p['id'],
        'name': p['name'],
        'apy': p['apy'],
        'min_amount': p['min_amount'],
        'lock_period': p['lock_period'],
        'total_staked': p['total_staked']
    } for p in products])

@app.route('/api/wealth/stake', methods=['POST'])
@auth_required
def stake():
    """存入理财"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    product_id = data.get('product_id')
    amount = data.get('amount', 0)
    
    conn = get_db()
    
    # 验证产品
    product = conn.execute("SELECT * FROM wealth_products WHERE id = ?", (product_id,)).fetchone()
    if not product:
        conn.close()
        return jsonify({'error': 'Product not found'}), 404
    
    # 验证金额
    if amount < product['min_amount']:
        conn.close()
        return jsonify({'error': f'Minimum amount is {product["min_amount"]} QAI'}), 400
    
    # 验证余额
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    if user['balance'] < amount:
        conn.close()
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # 扣除余额
    conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (amount, user_id))
    
    # 创建理财记录
    end_date = datetime.now() + timedelta(days=product['lock_period']) if product['lock_period'] > 0 else None
    conn.execute("""
        INSERT INTO user_stakes (user_id, product_id, amount, end_date)
        VALUES (?, ?, ?, ?)
    """, (user_id, product_id, amount, end_date))
    
    # 更新产品总质押
    conn.execute("UPDATE wealth_products SET total_staked = total_staked + ? WHERE id = ?", (amount, product_id))
    
    conn.commit()
    conn.close()
    
    # 计算预期收益
    expected_reward = amount * (product['apy'] / 100) * (product['lock_period'] / 365) if product['lock_period'] > 0 else amount * (product['apy'] / 100)
    
    return jsonify({
        'success': True,
        'message': f'理财成功！投入 {amount} QAI，预期收益 {expected_reward:.2f} QAI',
        'expected_reward': expected_reward,
        'end_date': end_date.isoformat() if end_date else '灵活存取'
    })

@app.route('/api/wealth/positions', methods=['GET'])
@auth_required
def get_stake_positions():
    """获取理财持仓"""
    user_id = request.headers.get('X-User-ID')
    conn = get_db()
    
    stakes = conn.execute("""
        SELECT s.*, p.name, p.apy, p.lock_period
        FROM user_stakes s
        JOIN wealth_products p ON s.product_id = p.id
        WHERE s.user_id = ?
    """, (user_id,)).fetchall()
    
    conn.close()
    
    return jsonify([{
        'id': s['id'],
        'product_name': s['name'],
        'amount': s['amount'],
        'apy': s['apy'],
        'lock_period': s['lock_period'],
        'start_date': s['start_date'],
        'end_date': s['end_date'],
        'status': s['status']
    } for s in stakes])

# ----- 借贷 API -----

@app.route('/api/loan/apply', methods=['POST'])
@auth_required
def apply_loan():
    """申请贷款"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    amount = data.get('amount', 0)
    duration = data.get('duration', 30)  # 天数
    
    conn = get_db()
    user = conn.execute("SELECT balance, credit_score FROM users WHERE id = ?", (user_id,)).fetchone()
    
    if not user:
        conn.close()
        return jsonify({'error': 'User not found'}), 404
    
    # 验证信用分
    if user['credit_score'] < 600:
        conn.close()
        return jsonify({'error': 'Credit score too low'}), 400
    
    # 计算额度
    max_loan = user['credit_score'] * 10
    if amount > max_loan:
        conn.close()
        return jsonify({'error': f'Exceeds credit limit. Max: {max_loan} QAI'}), 400
    
    # 计算利率和利息
    interest_rate = 10 - (user['credit_score'] / 100)  # 10% - 信用分/100
    interest = amount * (interest_rate / 100) * (duration / 30)
    
    # 创建贷款记录
    due_date = datetime.now() + timedelta(days=duration)
    conn.execute("""
        INSERT INTO loans (user_id, principal, interest, due_date)
        VALUES (?, ?, ?, ?)
    """, (user_id, amount, interest, due_date))
    
    # 增加余额
    conn.execute("UPDATE users SET balance = balance + ? WHERE id = ?", (amount, user_id))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'贷款成功！{amount} QAI 已到账',
        'principal': amount,
        'interest': interest,
        'total_repayment': amount + interest,
        'due_date': due_date.isoformat(),
        'interest_rate': interest_rate
    })

@app.route('/api/loan/repay', methods=['POST'])
@auth_required
def repay_loan():
    """偿还贷款"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    loan_id = data.get('loan_id')
    
    conn = get_db()
    loan = conn.execute("SELECT * FROM loans WHERE id = ?", (loan_id,)).fetchone()
    
    if not loan or loan['user_id'] != user_id:
        conn.close()
        return jsonify({'error': 'Loan not found'}), 404
    
    if loan['status'] == 'repaid':
        conn.close()
        return jsonify({'error': 'Loan already repaid'}), 400
    
    total_amount = loan['principal'] + loan['interest']
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    
    if user['balance'] < total_amount:
        conn.close()
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # 扣除余额
    conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (total_amount, user_id))
    
    # 更新贷款状态
    conn.execute("UPDATE loans SET status = 'repaid' WHERE id = ?", (loan_id,))
    
    # 提升信用分
    conn.execute("UPDATE users SET credit_score = MIN(850, credit_score + 10) WHERE id = ?", (user_id,))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': '贷款已还清，信用分 +10'
    })

# ----- 商城 API -----

@app.route('/api/marketplace/products', methods=['GET'])
def get_products():
    """获取商品列表"""
    conn = get_db()
    products = conn.execute("SELECT * FROM products WHERE is_active = 1").fetchall()
    conn.close()
    
    return jsonify([{
        'id': p['id'],
        'name': p['name'],
        'description': p['description'],
        'price': p['price'],
        'supply': p['supply'],
        'sold': p['sold'],
        'is_nft': bool(p['is_nft']),
        'ipfs_hash': p['ipfs_hash']
    } for p in products])

@app.route('/api/marketplace/buy', methods=['POST'])
@auth_required
def buy_product():
    """购买商品"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    product_id = data.get('product_id')
    
    conn = get_db()
    
    # 验证商品
    product = conn.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
    if not product:
        conn.close()
        return jsonify({'error': 'Product not found'}), 404
    
    if product['sold'] >= product['supply']:
        conn.close()
        return jsonify({'error': 'Out of stock'}), 400
    
    # 验证余额
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    if user['balance'] < product['price']:
        conn.close()
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # 扣除余额
    conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (product['price'], user_id))
    
    # 更新销量
    conn.execute("UPDATE products SET sold = sold + 1 WHERE id = ?", (product_id,))
    
    # 创建订单
    conn.execute("INSERT INTO orders (user_id, product_id, price) VALUES (?, ?, ?)",
                 (user_id, product_id, product['price']))
    
    # 如果是 NFT，铸造 NFT
    nft_token_id = None
    if product['is_nft']:
        nft_token_id = f"NFT-{uuid.uuid4().hex[:12]}"
        conn.execute("""
            INSERT INTO nfts (token_id, product_id, owner_id, metadata)
            VALUES (?, ?, ?, ?)
        """, (nft_token_id, product_id, user_id, product['description']))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'购买成功！{product["name"]}',
        'order_id': uuid.uuid4().hex[:12],
        'nft_token_id': nft_token_id,
        'nft_minted': bool(nft_token_id)
    })

@app.route('/api/marketplace/nfts', methods=['GET'])
@auth_required
def get_user_nfts():
    """获取用户 NFT 列表"""
    user_id = request.headers.get('X-User-ID')
    conn = get_db()
    
    nfts = conn.execute("""
        SELECT n.*, p.name as product_name
        FROM nfts n
        JOIN products p ON n.product_id = p.id
        WHERE n.owner_id = ?
    """, (user_id,)).fetchall()
    
    conn.close()
    
    return jsonify([{
        'token_id': n['token_id'],
        'product_name': n['product_name'],
        'metadata': n['metadata'],
        'created_at': n['created_at']
    } for n in nfts])

# ----- 跨链桥 API -----

@app.route('/api/bridge/transfer', methods=['POST'])
@auth_required
def bridge_transfer():
    """跨链转账"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    source_chain = data.get('source_chain')
    target_chain = data.get('target_chain')
    amount = data.get('amount', 0)
    
    if amount <= 0:
        return jsonify({'error': 'Invalid amount'}), 400
    
    fee = amount * 0.005  # 0.5% 手续费
    actual_amount = amount - fee
    
    conn = get_db()
    
    # 验证余额
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    if user['balance'] < amount:
        conn.close()
        return jsonify({'error': 'Insufficient balance'}), 400
    
    # 扣除余额
    conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (amount, user_id))
    
    # 创建跨链交易记录
    completed_at = datetime.now() + timedelta(minutes=10)  # 预计 10 分钟到账
    conn.execute("""
        INSERT INTO bridge_transactions (user_id, source_chain, target_chain, amount, fee, completed_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (user_id, source_chain, target_chain, amount, fee, completed_at))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': f'跨链交易已发起！预计 10 分钟后在{target_chain}收到 {actual_amount:.2f} QAI',
        'transaction_id': uuid.uuid4().hex[:12],
        'fee': fee,
        'actual_amount': actual_amount,
        'estimated_time': '5-10 分钟'
    })

# ----- 治理 API -----

@app.route('/api/governance/proposals', methods=['GET'])
def get_proposals():
    """获取治理提案列表"""
    conn = get_db()
    proposals = conn.execute("SELECT * FROM proposals WHERE status = 'active'").fetchall()
    conn.close()
    
    return jsonify([{
        'id': p['id'],
        'title': p['title'],
        'description': p['description'],
        'for_votes': p['for_votes'],
        'against_votes': p['against_votes'],
        'end_date': p['end_date'],
        'status': p['status']
    } for p in proposals])

@app.route('/api/governance/vote', methods=['POST'])
@auth_required
def vote():
    """投票"""
    user_id = request.headers.get('X-User-ID')
    data = request.json
    proposal_id = data.get('proposal_id')
    support = data.get('support', True)  # True=赞成，False=反对
    
    conn = get_db()
    
    # 验证提案
    proposal = conn.execute("SELECT * FROM proposals WHERE id = ?", (proposal_id,)).fetchone()
    if not proposal:
        conn.close()
        return jsonify({'error': 'Proposal not found'}), 404
    
    # 检查是否已投票
    existing_vote = conn.execute("""
        SELECT * FROM votes WHERE user_id = ? AND proposal_id = ?
    """, (user_id, proposal_id)).fetchone()
    
    if existing_vote:
        conn.close()
        return jsonify({'error': 'Already voted'}), 400
    
    # 获取用户投票权 (基于余额)
    user = conn.execute("SELECT balance FROM users WHERE id = ?", (user_id,)).fetchone()
    voting_power = int(user['balance'])
    
    # 记录投票
    conn.execute("""
        INSERT INTO votes (user_id, proposal_id, support, voting_power)
        VALUES (?, ?, ?, ?)
    """, (user_id, proposal_id, support, voting_power))
    
    # 更新票数
    if support:
        conn.execute("UPDATE proposals SET for_votes = for_votes + ? WHERE id = ?", (voting_power, proposal_id))
    else:
        conn.execute("UPDATE proposals SET against_votes = against_votes + ? WHERE id = ?", (voting_power, proposal_id))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'message': '投票成功',
        'voting_power': voting_power
    })

# ============ 主函数 ============

if __name__ == '__main__':
    # 初始化数据库
    init_db()
    
    # 启动服务
    print("\n🚀 量子 AI 公链后端服务启动中...")
    print("=" * 60)
    print("API 文档：http://localhost:5000/api/health")
    print("服务地址：http://localhost:5000")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
