#!/bin/bash
# 量子 AI 公链 - 后端服务启动脚本

set -e

echo "🚀 量子 AI 公链后端服务启动脚本"
echo "=================================="

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误：需要 Python 3"
    exit 1
fi

# 进入后端目录
cd "$(dirname "$0")"

# 安装依赖
echo ""
echo "📦 安装依赖..."
pip3 install -r requirements.txt

# 初始化数据库
echo ""
echo "💾 初始化数据库..."
python3 -c "from app import init_db; init_db()"

# 启动服务
echo ""
echo "🌐 启动后端服务..."
echo ""
python3 app.py
