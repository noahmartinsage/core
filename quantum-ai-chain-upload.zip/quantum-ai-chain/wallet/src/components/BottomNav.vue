<template>
  <nav class="bottom-nav">
    <router-link 
      v-for="item in items" 
      :key="item.route"
      :to="item.route"
      class="nav-item"
      active-class="active"
    >
      <div class="nav-icon">{{ item.icon }}</div>
      <div class="nav-label">{{ item.label }}</div>
    </router-link>
  </nav>
</template>

<script>
export default {
  name: 'BottomNav',
  data() {
    return {
      items: [
        { icon: '🏠', label: '首页', route: '/' },
        { icon: '🤖', label: 'AI', route: '/ai' },
        { icon: '🌐', label: '生态', route: '/ecosystem' },
        { icon: '💬', label: '消息', route: '/messages' },
        { icon: '👤', label: '我的', route: '/profile' }
      ]
    }
  }
}
</script>

<style scoped>
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(26, 26, 37, 0.95);
  backdrop-filter: blur(10px);
  border-top: 1px solid rgba(0, 102, 255, 0.3);
  display: flex;
  justify-content: space-around;
  padding: 8px 0;
  padding-bottom: calc(8px + env(safe-area-inset-bottom));
  z-index: 1000;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 8px 16px;
  text-decoration: none;
  color: #A0A0B0;
  transition: all 0.3s ease;
  border-radius: 12px;
}

.nav-item:hover {
  background: rgba(0, 102, 255, 0.1);
  color: #FFFFFF;
}

.nav-item.active {
  color: #00D9FF;
  background: rgba(0, 102, 255, 0.2);
}

.nav-icon {
  font-size: 1.5em;
}

.nav-label {
  font-size: 0.75em;
  font-weight: 500;
}
</style>
