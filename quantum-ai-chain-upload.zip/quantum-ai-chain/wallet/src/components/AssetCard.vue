<template>
  <div class="asset-card">
    <div class="card-header">
      <h3 class="card-title">💰 资产总额 (USDT)</h3>
      <div class="card-actions">
        <button @click="toggleVisibility" class="icon-btn">
          {{ showBalance ? '👁️' : '👁️🗨️' }}
        </button>
        <button @click="openAnalytics" class="icon-btn">📊</button>
      </div>
    </div>
    
    <div class="card-body">
      <div class="balance-display">
        <span class="balance-currency">$</span>
        <span class="balance-amount">
          {{ showBalance ? formatNumber(balance) : '****' }}
        </span>
      </div>
      <div class="balance-change" :class="changeClass">
        {{ change >= 0 ? '+' : '' }}{{ change }}%
      </div>
    </div>
    
    <div class="card-footer">
      <button class="action-btn deposit" @click="deposit">
        <span class="btn-icon">↓</span>
        <span class="btn-label">充值</span>
      </button>
      <button class="action-btn withdraw" @click="withdraw">
        <span class="btn-icon">↑</span>
        <span class="btn-label">提现</span>
      </button>
      <button class="action-btn swap" @click="swap">
        <span class="btn-icon">⇄</span>
        <span class="btn-label">兑换</span>
      </button>
      <button class="action-btn stake" @click="stake">
        <span class="btn-icon">🛡️</span>
        <span class="btn-label">质押</span>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AssetCard',
  data() {
    return {
      showBalance: true,
      balance: 10240.50,
      change: 2.5
    }
  },
  computed: {
    changeClass() {
      return this.change >= 0 ? 'positive' : 'negative'
    }
  },
  methods: {
    toggleVisibility() {
      this.showBalance = !this.showBalance
    },
    openAnalytics() {
      this.$emit('open-analytics')
    },
    formatNumber(num) {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    },
    deposit() {
      this.$emit('deposit')
    },
    withdraw() {
      this.$emit('withdraw')
    },
    swap() {
      this.$emit('swap')
    },
    stake() {
      this.$emit('stake')
    }
  }
}
</script>

<style scoped>
.asset-card {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(0, 102, 255, 0.3);
  transition: all 0.3s ease;
}

.asset-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.card-title {
  font-size: 1.1em;
  color: #FFFFFF;
  margin: 0;
}

.card-actions {
  display: flex;
  gap: 10px;
}

.icon-btn {
  background: none;
  border: none;
  font-size: 1.2em;
  cursor: pointer;
  padding: 5px;
  border-radius: 8px;
  transition: background 0.3s ease;
}

.icon-btn:hover {
  background: rgba(0, 102, 255, 0.2);
}

.card-body {
  margin-bottom: 24px;
}

.balance-display {
  display: flex;
  align-items: baseline;
  margin-bottom: 8px;
}

.balance-currency {
  font-size: 1.5em;
  color: #00D9FF;
  margin-right: 5px;
}

.balance-amount {
  font-size: 2.5em;
  font-weight: bold;
  background: linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.balance-change {
  font-size: 1em;
  font-weight: bold;
}

.balance-change.positive {
  color: #00FF88;
}

.balance-change.negative {
  color: #FF3366;
}

.card-footer {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.action-btn {
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  border: none;
  border-radius: 12px;
  padding: 12px 8px;
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;
}

.action-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 5px 20px rgba(0, 102, 255, 0.4);
}

.btn-icon {
  font-size: 1.3em;
}

.btn-label {
  font-size: 0.8em;
}
</style>
