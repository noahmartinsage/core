<template>
  <div class="function-grid">
    <div class="grid-container">
      <button 
        v-for="item in items" 
        :key="item.label"
        class="grid-item"
        @click="handleClick(item)"
        :style="{ background: item.gradient }"
      >
        <div class="item-icon">{{ item.icon }}</div>
        <div class="item-label">{{ item.label }}</div>
        <div class="item-sublabel">{{ item.sublabel }}</div>
        <div v-if="item.badge" class="item-badge">{{ item.badge }}</div>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FunctionGrid',
  data() {
    return {
      items: [
        {
          icon: '🏦',
          label: '金融',
          sublabel: 'AI 理财',
          route: '/finance',
          gradient: 'linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%)'
        },
        {
          icon: '🛒',
          label: '商城',
          sublabel: '溯源商城',
          route: '/marketplace',
          gradient: 'linear-gradient(135deg, #00D9FF 0%, #00FF88 100%)'
        },
        {
          icon: '🤖',
          label: 'AI',
          sublabel: '智能体管理',
          route: '/ai',
          gradient: 'linear-gradient(135deg, #FF006E 0%, #FFBE00 100%)'
        },
        {
          icon: '⛏️',
          label: '挖矿',
          sublabel: '量子挖矿',
          route: '/mining',
          gradient: 'linear-gradient(135deg, #0066FF 0%, #00FF88 100%)'
        },
        {
          icon: '👥',
          label: '团队',
          sublabel: '我的团队',
          route: '/team',
          gradient: 'linear-gradient(135deg, #7B2CBF 0%, #FF006E 100%)'
        },
        {
          icon: '📊',
          label: '数据',
          sublabel: '链上数据',
          route: '/analytics',
          gradient: 'linear-gradient(135deg, #00D9FF 0%, #7B2CBF 100%)'
        },
        {
          icon: '🎓',
          label: '学院',
          sublabel: '学习中心',
          route: '/academy',
          gradient: 'linear-gradient(135deg, #FFBE00 0%, #FF006E 100%)'
        },
        {
          icon: '🔗',
          label: '跨链',
          sublabel: '资产桥',
          route: '/bridge',
          gradient: 'linear-gradient(135deg, #0066FF 0%, #00D9FF 100%)'
        },
        {
          icon: '🎁',
          label: '任务',
          sublabel: 'AI 任务',
          route: '/tasks',
          gradient: 'linear-gradient(135deg, #00FF88 0%, #00D9FF 100%)',
          badge: 'NEW'
        },
        {
          icon: '🎫',
          label: 'NFT',
          sublabel: '数字版权',
          route: '/nft',
          gradient: 'linear-gradient(135deg, #FF006E 0%, #7B2CBF 100%)'
        },
        {
          icon: '🗳️',
          label: '治理',
          sublabel: 'DAO 投票',
          route: '/governance',
          gradient: 'linear-gradient(135deg, #7B2CBF 0%, #0066FF 100%)'
        },
        {
          icon: '📱',
          label: '钱包',
          sublabel: '资产管理',
          route: '/wallet',
          gradient: 'linear-gradient(135deg, #00D9FF 0%, #00FF88 100%)'
        },
        {
          icon: '❓',
          label: '帮助',
          sublabel: '帮助中心',
          route: '/help',
          gradient: 'linear-gradient(135deg, #606070 0%, #A0A0B0 100%)'
        },
        {
          icon: '📢',
          label: '公告',
          sublabel: '系统公告',
          route: '/announcements',
          gradient: 'linear-gradient(135deg, #FFBE00 0%, #FF006E 100%)'
        },
        {
          icon: '⚙️',
          label: '设置',
          sublabel: '系统设置',
          route: '/settings',
          gradient: 'linear-gradient(135deg, #A0A0B0 0%, #606070 100%)'
        },
        {
          icon: '🌐',
          label: '生态',
          sublabel: '生态圈',
          route: '/ecosystem',
          gradient: 'linear-gradient(135deg, #00FF88 0%, #00D9FF 100%)'
        }
      ]
    }
  },
  methods: {
    handleClick(item) {
      if (item.route) {
        this.$router.push(item.route)
      }
      this.$emit('click', item)
    }
  }
}
</script>

<style scoped>
.function-grid {
  padding: 20px 0;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 15px;
}

.grid-item {
  background: rgba(26, 26, 37, 0.8);
  border: none;
  border-radius: 16px;
  padding: 20px 10px;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  backdrop-filter: blur(10px);
}

.grid-item:hover {
  transform: translateY(-5px) scale(1.05);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
}

.item-icon {
  font-size: 2em;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3));
}

.item-label {
  color: #FFFFFF;
  font-size: 0.95em;
  font-weight: bold;
  text-align: center;
}

.item-sublabel {
  color: #A0A0B0;
  font-size: 0.75em;
  text-align: center;
}

.item-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  background: linear-gradient(135deg, #FF006E 0%, #FFBE00 100%);
  color: white;
  font-size: 0.65em;
  font-weight: bold;
  padding: 3px 8px;
  border-radius: 10px;
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-3px); }
}

@media (max-width: 768px) {
  .grid-container {
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
  }
  
  .grid-item {
    padding: 15px 8px;
  }
  
  .item-icon {
    font-size: 1.5em;
  }
  
  .item-label {
    font-size: 0.85em;
  }
  
  .item-sublabel {
    font-size: 0.65em;
  }
}
</style>
