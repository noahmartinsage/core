<template>
  <div class="ai-earn-card">
    <div class="card-header">
      <h3 class="card-title">🤖 AI 收益</h3>
      <div class="card-actions">
        <button @click="toggleVisibility" class="icon-btn">👁️</button>
        <button @click="toggleMining" class="play-btn">
          {{ isMining ? '⏸️' : '▶️' }}
        </button>
      </div>
    </div>
    
    <div class="card-body">
      <div class="earn-display">
        <span class="earn-amount">
          {{ showBalance ? formatNumber(balance) : '****' }}
        </span>
        <span class="earn-currency">QAI</span>
      </div>
      
      <div class="mining-status" :class="{ active: isMining }">
        <span class="status-indicator">●</span>
        <span class="status-text">
          {{ isMining ? `释放 ${releaseRate} QAI/小时` : '已暂停' }}
        </span>
      </div>
      
      <div class="mining-sources">
        <div class="source-item" v-for="source in sources" :key="source.name">
          <div class="source-info">
            <span class="source-icon">{{ source.icon }}</span>
            <span class="source-name">{{ source.name }}</span>
          </div>
          <div class="source-rate">
            +{{ source.rate }} QAI/h
          </div>
        </div>
      </div>
      
      <div class="daily-estimate">
        <span class="estimate-label">预计日收益:</span>
        <span class="estimate-value">
          {{ (totalRate * 24).toFixed(2) }} QAI ≈ ${{ (totalRate * 24 * 0.15).toFixed(2) }}
        </span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AIEarnCard',
  data() {
    return {
      showBalance: true,
      balance: 125.50,
      isMining: true,
      releaseRate: 8.5,
      sources: [
        { name: 'AI 任务', icon: '📋', rate: 2.5 },
        { name: '质押挖矿', icon: '🛡️', rate: 5.0 },
        { name: '内容贡献', icon: '📝', rate: 1.0 }
      ]
    }
  },
  computed: {
    totalRate() {
      return this.sources.reduce((sum, source) => sum + source.rate, 0)
    }
  },
  methods: {
    toggleVisibility() {
      this.showBalance = !this.showBalance
    },
    toggleMining() {
      this.isMining = !this.isMining
      if (this.isMining) {
        this.startMining()
      } else {
        this.stopMining()
      }
    },
    startMining() {
      this.$emit('mining-start')
    },
    stopMining() {
      this.$emit('mining-stop')
    },
    formatNumber(num) {
      return num.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      })
    }
  }
}
</script>

<style scoped>
.ai-earn-card {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(10px);
  border: 2px solid transparent;
  background-image: linear-gradient(rgba(26, 26, 37, 0.8), rgba(26, 26, 37, 0.8)),
                    linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  background-origin: border-box;
  background-clip: padding-box, border-box;
  transition: all 0.3s ease;
}

.ai-earn-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 217, 255, 0.3);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.card-title {
  font-size: 1.1em;
  color: #FFFFFF;
  margin: 0;
}

.card-actions {
  display: flex;
  gap: 10px;
}

.icon-btn, .play-btn {
  background: none;
  border: none;
  font-size: 1.2em;
  cursor: pointer;
  padding: 5px 10px;
  border-radius: 8px;
  transition: background 0.3s ease;
}

.icon-btn:hover, .play-btn:hover {
  background: rgba(0, 217, 255, 0.2);
}

.card-body {
  margin-top: 10px;
}

.earn-display {
  display: flex;
  align-items: baseline;
  margin-bottom: 15px;
}

.earn-amount {
  font-size: 2.5em;
  font-weight: bold;
  background: linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.earn-currency {
  font-size: 1.2em;
  color: #00D9FF;
  margin-left: 10px;
}

.mining-status {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
  background: rgba(0, 0, 0, 0.3);
  border-radius: 12px;
  margin-bottom: 20px;
  color: #A0A0B0;
}

.mining-status.active {
  color: #00FF88;
}

.mining-status.active .status-indicator {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.status-indicator {
  font-size: 0.8em;
}

.mining-sources {
  margin-bottom: 20px;
}

.source-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background: rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  margin-bottom: 8px;
}

.source-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.source-icon {
  font-size: 1.2em;
}

.source-name {
  color: #FFFFFF;
}

.source-rate {
  color: #00FF88;
  font-weight: bold;
}

.daily-estimate {
  display: flex;
  justify-content: space-between;
  padding: 15px;
  background: linear-gradient(135deg, rgba(0, 102, 255, 0.2) 0%, rgba(123, 44, 191, 0.2) 100%);
  border-radius: 12px;
  border: 1px solid rgba(0, 102, 255, 0.3);
}

.estimate-label {
  color: #A0A0B0;
}

.estimate-value {
  color: #00D9FF;
  font-weight: bold;
}
</style>
