<template>
  <div class="quantum-security-card">
    <div class="card-header">
      <h3 class="card-title">🛡️ 量子安全状态</h3>
      <span class="security-level" :class="overallStatus">
        {{ statusText }}
      </span>
    </div>
    
    <div class="security-layers">
      <div class="layer" v-for="layer in layers" :key="layer.name">
        <div class="layer-header">
          <div class="layer-info">
            <span class="layer-icon">{{ layer.icon }}</span>
            <div>
              <div class="layer-name">{{ layer.name }}</div>
              <div class="layer-desc">{{ layer.description }}</div>
            </div>
          </div>
          <span class="layer-status" :class="layer.status">
            {{ statusMap[layer.status] }}
          </span>
        </div>
        
        <div class="layer-details" v-if="layer.details">
          <div class="detail-item" v-for="(detail, index) in layer.details" :key="index">
            <span class="detail-icon">✓</span>
            <span class="detail-text">{{ detail }}</span>
          </div>
        </div>
        
        <div class="layer-timeline" v-if="layer.timeline">
          <div class="timeline-label">预计上线：{{ layer.timeline }}</div>
        </div>
      </div>
    </div>
    
    <div class="security-score">
      <div class="score-header">
        <span>整体安全评分</span>
        <span class="score-value">{{ score }}/100</span>
      </div>
      <div class="score-bar">
        <div class="score-fill" :style="{ width: score + '%' }"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'QuantumSecurityCard',
  data() {
    return {
      score: 85,
      statusMap: {
        active: '🟢 已激活',
        testing: '🟡 测试中',
        planning: '⚪ 规划中'
      },
      layers: [
        {
          icon: '🔐',
          name: 'PQC 层',
          description: '后量子密码学',
          status: 'active',
          details: [
            'ML-KEM (密钥封装)',
            'ML-DSA (数字签名)',
            'SLH-DSA (哈希签名)'
          ]
        },
        {
          icon: '🔑',
          name: 'QKD 层',
          description: '量子密钥分发',
          status: 'testing',
          timeline: 'Phase 2',
          details: [
            '量子密钥分发网络',
            '主节点自动轮换'
          ]
        },
        {
          icon: '💎',
          name: 'HSM 层',
          description: '硬件安全模块',
          status: 'planning',
          timeline: 'Phase 3',
          details: [
            '国产抗量子芯片',
            '40nm 工艺，0.16mW 功耗'
          ]
        }
      ]
    }
  },
  computed: {
    overallStatus() {
      const activeCount = this.layers.filter(l => l.status === 'active').length
      if (activeCount >= 2) return 'excellent'
      if (activeCount >= 1) return 'good'
      return 'fair'
    },
    statusText() {
      const map = {
        excellent: '🟢 优秀',
        good: '🟢 良好',
        fair: '🟡 一般'
      }
      return map[this.overallStatus]
    }
  }
}
</script>

<style scoped>
.quantum-security-card {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  padding: 24px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(0, 102, 255, 0.3);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.card-title {
  font-size: 1.1em;
  color: #FFFFFF;
  margin: 0;
}

.security-level {
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 0.85em;
  font-weight: bold;
}

.security-level.excellent {
  background: rgba(0, 255, 136, 0.2);
  color: #00FF88;
}

.security-level.good {
  background: rgba(0, 217, 255, 0.2);
  color: #00D9FF;
}

.security-level.fair {
  background: rgba(255, 190, 0, 0.2);
  color: #FFBE00;
}

.security-layers {
  margin-bottom: 20px;
}

.layer {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
}

.layer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.layer-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.layer-icon {
  font-size: 1.5em;
}

.layer-name {
  color: #FFFFFF;
  font-weight: bold;
  font-size: 0.95em;
}

.layer-desc {
  color: #A0A0B0;
  font-size: 0.8em;
}

.layer-status {
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 0.75em;
  font-weight: bold;
}

.layer-status.active {
  background: rgba(0, 255, 136, 0.2);
  color: #00FF88;
}

.layer-status.testing {
  background: rgba(255, 190, 0, 0.2);
  color: #FFBE00;
}

.layer-status.planning {
  background: rgba(160, 160, 176, 0.2);
  color: #A0A0B0;
}

.layer-details {
  margin-top: 10px;
}

.detail-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 0;
  color: #A0A0B0;
  font-size: 0.85em;
}

.detail-icon {
  color: #00FF88;
  font-weight: bold;
}

.layer-timeline {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.timeline-label {
  color: #00D9FF;
  font-size: 0.8em;
  font-weight: bold;
}

.security-score {
  background: rgba(0, 102, 255, 0.1);
  border-radius: 12px;
  padding: 16px;
  border: 1px solid rgba(0, 102, 255, 0.3);
}

.score-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  color: #A0A0B0;
}

.score-value {
  color: #00D9FF;
  font-weight: bold;
  font-size: 1.2em;
}

.score-bar {
  height: 8px;
  background: rgba(0, 102, 255, 0.2);
  border-radius: 4px;
  overflow: hidden;
}

.score-fill {
  height: 100%;
  background: linear-gradient(90deg, #0066FF 0%, #00FF88 100%);
  transition: width 0.5s ease;
}
</style>
