<template>
  <div class="marketplace">
    <!-- Header -->
    <header class="header">
      <h1>🛒 溯源商城</h1>
      <p>一物一证一权一链一溯源</p>
    </header>

    <!-- Search -->
    <div class="search-bar">
      <input type="text" placeholder="搜索商品或版权编号..." v-model="searchQuery" />
      <button @click="search">🔍</button>
    </div>

    <!-- Categories -->
    <div class="categories">
      <button 
        v-for="cat in categories" 
        :key="cat"
        :class="{ active: currentCategory === cat }"
        @click="currentCategory = cat"
      >
        {{ cat }}
      </button>
    </div>

    <!-- Products -->
    <div class="products">
      <div class="product-card" v-for="product in filteredProducts" :key="product.id">
        <div class="product-image">
          <img :src="product.image" :alt="product.name" />
          <span class="nft-badge">NFT</span>
        </div>
        <div class="product-info">
          <h3>{{ product.name }}</h3>
          <p class="product-id">编号：{{ product.id }}</p>
          <p class="product-copyright">版权：{{ product.copyright }}</p>
          <div class="trace-info">
            <span class="trace-item">✓ 链上存证</span>
            <span class="trace-item">✓ 版权登记</span>
            <span class="trace-item">✓ 溯源可查</span>
          </div>
          <div class="product-price">
            <span class="price">{{ product.price }} QAI</span>
            <span class="price-usdt">≈ ${{ (product.price * 0.15).toFixed(2) }}</span>
          </div>
        </div>
        <div class="product-actions">
          <button class="buy-btn" @click="buy(product)">购买</button>
          <button class="trace-btn" @click="viewTrace(product)">溯源</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Marketplace',
  data() {
    return {
      searchQuery: '',
      currentCategory: '全部',
      categories: ['全部', '数字艺术', '实物商品', '版权 NFT', '限量版'],
      products: [
        {
          id: 'QAI-NFT-000001',
          name: '量子 AI 公链创世 NFT',
          image: '/images/nft-1.png',
          copyright: '量子 AI 公链团队',
          price: 1000,
          inStock: true
        },
        {
          id: 'QAI-NFT-000002',
          name: 'AI 智能体设计稿',
          image: '/images/nft-2.png',
          copyright: '昭君 AI 工作室',
          price: 500,
          inStock: true
        },
        {
          id: 'QAI-NFT-000003',
          name: '量子安全芯片 NFT',
          image: '/images/nft-3.png',
          copyright: 'CUn 芯片公司',
          price: 2000,
          inStock: false
        }
      ]
    }
  },
  computed: {
    filteredProducts() {
      return this.products.filter(p => 
        p.name.includes(this.searchQuery) || p.id.includes(this.searchQuery)
      )
    }
  },
  methods: {
    search() {
      console.log('Searching:', this.searchQuery)
    },
    buy(product) {
      this.$emit('buy', product)
    },
    viewTrace(product) {
      this.$emit('trace', product)
    }
  }
}
</script>

<style scoped>
.marketplace {
  min-height: 100vh;
  background: linear-gradient(135deg, #0A0A0F 0%, #12121A 100%);
  color: #FFFFFF;
  padding: 20px;
}

.header {
  text-align: center;
  margin-bottom: 30px;
}

.header h1 {
  font-size: 2em;
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 10px;
}

.search-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.search-bar input {
  flex: 1;
  padding: 12px 20px;
  background: rgba(26, 26, 37, 0.8);
  border: 1px solid rgba(0, 102, 255, 0.3);
  border-radius: 12px;
  color: #FFFFFF;
  font-size: 1em;
}

.search-bar button {
  padding: 12px 24px;
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  border: none;
  border-radius: 12px;
  color: white;
  cursor: pointer;
  font-size: 1.2em;
}

.categories {
  display: flex;
  gap: 10px;
  overflow-x: auto;
  margin-bottom: 20px;
  padding-bottom: 10px;
}

.categories button {
  padding: 8px 16px;
  background: rgba(26, 26, 37, 0.8);
  border: 1px solid rgba(0, 102, 255, 0.3);
  border-radius: 20px;
  color: #A0A0B0;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.3s ease;
}

.categories button.active {
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  color: white;
  border-color: transparent;
}

.products {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.product-card {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid rgba(0, 102, 255, 0.3);
  transition: transform 0.3s ease;
}

.product-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
}

.product-image {
  position: relative;
  height: 200px;
  background: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
}

.product-image img {
  max-width: 100%;
  max-height: 100%;
  object-fit: cover;
}

.nft-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: linear-gradient(135deg, #FF006E 0%, #FFBE00 100%);
  color: white;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.8em;
  font-weight: bold;
}

.product-info {
  padding: 16px;
}

.product-info h3 {
  font-size: 1.1em;
  margin-bottom: 8px;
  color: #FFFFFF;
}

.product-id, .product-copyright {
  color: #A0A0B0;
  font-size: 0.85em;
  margin-bottom: 4px;
}

.trace-info {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 12px 0;
}

.trace-item {
  color: #00FF88;
  font-size: 0.75em;
  background: rgba(0, 255, 136, 0.1);
  padding: 4px 8px;
  border-radius: 8px;
}

.product-price {
  margin: 12px 0;
}

.price {
  font-size: 1.5em;
  font-weight: bold;
  background: linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.price-usdt {
  color: #A0A0B0;
  font-size: 0.9em;
  margin-left: 10px;
}

.product-actions {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 16px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.buy-btn, .trace-btn {
  padding: 12px;
  border: none;
  border-radius: 12px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s ease;
}

.buy-btn {
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  color: white;
}

.trace-btn {
  background: rgba(0, 217, 255, 0.2);
  color: #00D9FF;
  border: 1px solid rgba(0, 217, 255, 0.3);
}

.buy-btn:hover, .trace-btn:hover {
  transform: scale(1.05);
}
</style>
