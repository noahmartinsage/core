<template>
  <div class="home">
    <!-- Header -->
    <header class="header">
      <div class="container">
        <h1>🌌 量子 AI 公链</h1>
        <p class="tagline">Quantum AI Chain - 量子安全 · AI 智能 · 万物互联</p>
      </div>
    </header>

    <!-- Stats -->
    <section class="stats">
      <div class="container">
        <div class="stat-card" v-for="stat in stats" :key="stat.label">
          <div class="stat-value">{{ stat.value }}</div>
          <div class="stat-label">{{ stat.label }}</div>
        </div>
      </div>
    </section>

    <!-- Progress -->
    <section class="progress-section">
      <div class="container">
        <h2>📊 开发进度</h2>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: progress + '%' }">
            {{ progress }}%
          </div>
        </div>
      </div>
    </section>

    <!-- Features -->
    <section class="features">
      <div class="container">
        <div class="feature-card" v-for="feature in features" :key="feature.title">
          <h3>{{ feature.icon }} {{ feature.title }}</h3>
          <p>{{ feature.description }}</p>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
      progress: 15,
      stats: [
        { label: '目标 TPS', value: '1,000+' },
        { label: 'AI 开发者', value: '50-100' },
        { label: '设计文档', value: '25+' },
        { label: '冲刺天数', value: '2' }
      ],
      features: [
        {
          icon: '🛡️',
          title: '量子安全三层架构',
          description: '融合 PQC+QKD+HSM，打造面向未来的量子安全区块链基础设施'
        },
        {
          icon: '🤖',
          title: 'K2.5 启发 AI 团队',
          description: '100-200 个 AI 开发者并行开发，24 小时不间断'
        },
        {
          icon: '💰',
          title: 'Automaton 金融模型',
          description: '"AI 赚钱 AI 花"机制，人人都是银行'
        },
        {
          icon: '🛒',
          title: '全链溯源商城',
          description: '"一物一证一权一链一溯源"，NFT 商品溯源系统'
        }
      ]
    }
  },
  mounted() {
    this.startProgressAnimation()
  },
  methods: {
    startProgressAnimation() {
      const interval = setInterval(() => {
        if (this.progress < 100) {
          this.progress += Math.random() * 2
          if (this.progress > 100) this.progress = 100
        } else {
          clearInterval(interval)
        }
      }, 5000)
    }
  }
}
</script>

<style scoped>
.home {
  min-height: 100vh;
  background: linear-gradient(135deg, #0A0A0F 0%, #12121A 100%);
  color: #FFFFFF;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.header {
  text-align: center;
  padding: 60px 20px;
  background: radial-gradient(circle at center, rgba(0,102,255,0.2) 0%, transparent 70%);
}

.header h1 {
  font-size: 3em;
  background: linear-gradient(135deg, #0066FF 0%, #7B2CBF 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 20px;
}

.tagline {
  font-size: 1.2em;
  color: #A0A0B0;
}

.stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin: 40px 0;
}

.stat-card {
  background: rgba(26, 26, 37, 0.8);
  border: 1px solid rgba(0, 102, 255, 0.3);
  border-radius: 16px;
  padding: 30px;
  text-align: center;
  backdrop-filter: blur(10px);
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
}

.stat-value {
  font-size: 2.5em;
  font-weight: bold;
  background: linear-gradient(135deg, #00D9FF 0%, #00FF88 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.stat-label {
  color: #A0A0B0;
  margin-top: 10px;
  font-size: 0.9em;
}

.progress-section {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  padding: 40px;
  margin: 60px 0;
}

.progress-bar {
  width: 100%;
  height: 30px;
  background: rgba(0, 102, 255, 0.2);
  border-radius: 15px;
  overflow: hidden;
  margin: 20px 0;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #0066FF 0%, #00FF88 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  transition: width 0.5s ease;
}

.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin: 60px 0;
}

.feature-card {
  background: rgba(26, 26, 37, 0.8);
  border-radius: 16px;
  padding: 30px;
  border-left: 4px solid #0066FF;
}

.feature-card h3 {
  color: #00D9FF;
  margin-bottom: 15px;
}

.feature-card p {
  color: #A0A0B0;
  line-height: 1.6;
}
</style>
