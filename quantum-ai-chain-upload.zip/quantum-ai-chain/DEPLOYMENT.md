# 量子 AI 公链 - 部署指南

## 📋 系统要求

- Python 3.8+
- Node.js 18+ (可选，用于前端开发)
- 2GB+ RAM
- 10GB+ 存储空间

---

## 🚀 快速部署

### 1. 安装后端依赖

```bash
cd quantum-ai-chain/backend
pip3 install -r requirements.txt
```

### 2. 启动后端服务

**方法 A: 使用启动脚本**
```bash
./start.sh
```

**方法 B: 手动启动**
```bash
python3 app.py
```

服务将在 `http://localhost:5000` 启动

### 3. 打开前端应用

在浏览器中打开：
```
file:///path/to/quantum-ai-chain/app-full.html
```

或者使用本地服务器：
```bash
cd quantum-ai-chain
python3 -m http.server 8080
```

然后访问：`http://localhost:8080/app-full.html`

---

## 📊 API 文档

### 健康检查
```bash
GET http://localhost:5000/api/health
```

### 钱包接口

**获取钱包信息**
```bash
GET http://localhost:5000/api/wallet
Headers: X-User-ID: <user_id>
```

**充值**
```bash
POST http://localhost:5000/api/wallet/deposit
Headers: X-User-ID: <user_id>
Body: {"amount": 1000}
```

### 理财接口

**获取理财产品**
```bash
GET http://localhost:5000/api/wealth/products
```

**存入理财**
```bash
POST http://localhost:5000/api/wealth/stake
Headers: X-User-ID: <user_id>
Body: {"product_id": 1, "amount": 1000}
```

### 借贷接口

**申请贷款**
```bash
POST http://localhost:5000/api/loan/apply
Headers: X-User-ID: <user_id>
Body: {"amount": 1000, "duration": 30}
```

### 商城接口

**获取商品列表**
```bash
GET http://localhost:5000/api/marketplace/products
```

**购买商品**
```bash
POST http://localhost:5000/api/marketplace/buy
Headers: X-User-ID: <user_id>
Body: {"product_id": 1}
```

### 跨链接口

**跨链转账**
```bash
POST http://localhost:5000/api/bridge/transfer
Headers: X-User-ID: <user_id>
Body: {
  "source_chain": "Quantum AI Chain",
  "target_chain": "Ethereum",
  "amount": 100
}
```

### 治理接口

**获取提案列表**
```bash
GET http://localhost:5000/api/governance/proposals
```

**投票**
```bash
POST http://localhost:5000/api/governance/vote
Headers: X-User-ID: <user_id>
Body: {"proposal_id": 1, "support": true}
```

---

## 🗄️ 数据库

数据库文件：`quantum-ai-chain/backend/quantum_chain.db`

**数据表**:
- `users` - 用户表
- `wealth_products` - 理财产品表
- `user_stakes` - 用户理财记录
- `loans` - 贷款表
- `products` - 商品表
- `orders` - 订单表
- `nfts` - NFT 表
- `bridge_transactions` - 跨链交易表
- `proposals` - 治理提案表
- `votes` - 投票记录表

**重置数据库**:
```bash
rm quantum-ai-chain/backend/quantum_chain.db
# 重启后端服务会自动重新初始化
```

---

## 🔧 配置选项

### 环境变量

```bash
# 服务端口 (默认：5000)
export QUANTUM_PORT=5000

# 数据库路径 (默认：./quantum_chain.db)
export QUANTUM_DB_PATH=/path/to/db.sqlite
```

### 修改配置

编辑 `backend/app.py`:
- 修改 `app.run()` 的 `port` 参数更改端口
- 修改 `DB_PATH` 更改数据库位置

---

## 📝 功能特性

### ✅ 已实现功能

1. **钱包系统**
   - ✅ 自动创建钱包
   - ✅ 余额查询
   - ✅ 充值/提现

2. **AI 理财**
   - ✅ 3 个理财产品 (8%/15%/20% APY)
   - ✅ 灵活存取/锁定期
   - ✅ 预期收益计算

3. **AI 借贷**
   - ✅ 信用评分系统
   - ✅ 额度计算 (信用分*10)
   - ✅ 利率计算
   - ✅ 还款功能

4. **溯源商城**
   - ✅ 商品列表
   - ✅ 购买功能
   - ✅ NFT 铸造
   - ✅ 订单管理

5. **跨链桥**
   - ✅ 5 条链支持
   - ✅ 手续费计算 (0.5%)
   - ✅ 交易记录

6. **DAO 治理**
   - ✅ 提案列表
   - ✅ 投票功能
   - ✅ 票数统计

---

## 🎯 使用说明

### 第一次使用

1. 打开 `app-full.html`
2. 系统会自动创建钱包并赠送 10,000 QAI 测试币
3. 开始体验各种功能

### 理财流程

1. 点击"理财"标签
2. 选择理财产品
3. 输入投入金额
4. 确认投入
5. 查看预期收益

### 借贷流程

1. 点击"借贷"标签
2. 输入借款金额和期限
3. 查看利率和应还总额
4. 确认借款
5. 到期还款

### 购物流程

1. 点击"商城"标签
2. 浏览商品
3. 点击"立即购买"
4. 确认购买
5. 获得商品/NFT

### 跨链流程

1. 点击"跨链"标签
2. 选择源链和目标链
3. 输入金额
4. 确认跨链
5. 等待到账 (5-10 分钟)

### 投票流程

1. 点击"治理"标签
2. 查看提案
3. 点击"投赞成票"
4. 投票成功

---

## 🐛 故障排除

### 后端无法启动

**检查 Python 版本**:
```bash
python3 --version  # 需要 3.8+
```

**检查依赖**:
```bash
pip3 install -r requirements.txt
```

### 前端无法连接后端

**检查后端服务**:
```bash
curl http://localhost:5000/api/health
```

**检查 CORS**:
确保后端已启用 CORS (已默认启用)

### 数据库错误

**删除并重建数据库**:
```bash
rm backend/quantum_chain.db
python3 backend/app.py
```

---

## 📞 技术支持

- **GitHub**: https://github.com/noahmartinsage/core
- **文档**: 查看项目文档目录
- **邮箱**: dev@quantum-ai-chain.org

---

**版本**: 1.0.0  
**最后更新**: 2026-04-06  
**状态**: 生产就绪 ✅
