#!/usr/bin/env python3
"""EvoMap 节点注册脚本"""

import requests
import json
from datetime import datetime
import random

def generate_message_id():
    """生成唯一消息 ID"""
    timestamp = int(datetime.now().timestamp() * 1000)
    random_hex = ''.join(random.choices('0123456789abcdef', k=8))
    return f"msg_{timestamp}_{random_hex}"

def hello_register():
    """注册 EvoMap 节点"""
    
    url = "https://evomap.ai/a2a/hello"
    
    payload = {
        "protocol": "gep-a2a",
        "protocol_version": "1.0.0",
        "message_type": "hello",
        "message_id": generate_message_id(),
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "payload": {
            "capabilities": {},
            "model": "claude-sonnet-4",
            "env_fingerprint": {
                "platform": "linux",
                "arch": "x64"
            }
        }
    }
    
    print("🚀 正在注册 EvoMap 节点...")
    print(f"请求 URL: {url}")
    print(f"消息 ID: {payload['message_id']}")
    print("-" * 60)
    
    try:
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        
        print("✅ 注册成功!")
        print("-" * 60)
        
        if "payload" in result:
            data = result["payload"]
            print(f"节点 ID: {data.get('your_node_id', 'N/A')}")
            print(f"节点密钥：{data.get('node_secret', 'N/A')[:20]}...")
            print(f"认领码：{data.get('claim_code', 'N/A')}")
            print(f"认领 URL: {data.get('claim_url', 'N/A')}")
            print(f"HUB 节点 ID: {data.get('hub_node_id', 'N/A')}")
            print(f"心跳间隔：{data.get('heartbeat_interval_ms', 'N/A')}ms")
            
            # 保存到文件
            save_credentials(data)
            
        return result
        
    except requests.exceptions.RequestException as e:
        print(f"❌ 请求失败：{e}")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ JSON 解析失败：{e}")
        print(f"原始响应：{response.text[:500]}")
        return None

def save_credentials(data):
    """保存凭证到文件"""
    import os
    
    secret_dir = os.path.expanduser("~/.openclaw/secrets")
    os.makedirs(secret_dir, exist_ok=True)
    
    cred_file = os.path.join(secret_dir, "evomap-credentials.env")
    
    with open(cred_file, "w") as f:
        f.write("# EvoMap Credentials\n")
        f.write(f"EVOMAP_NODE_ID=\"{data.get('your_node_id', '')}\"\n")
        f.write(f"EVOMAP_NODE_SECRET=\"{data.get('node_secret', '')}\"\n")
        f.write(f"EVOMAP_CLAIM_CODE=\"{data.get('claim_code', '')}\"\n")
        f.write(f"EVOMAP_HUB_NODE_ID=\"{data.get('hub_node_id', '')}\"\n")
        f.write(f"EVOMAP_HEARTBEAT_INTERVAL=\"{data.get('heartbeat_interval_ms', 300000)}\"\n")
    
    # 设置文件权限为 600
    os.chmod(cred_file, 0o600)
    
    print(f"\n💾 凭证已保存到：{cred_file}")
    print("🔒 文件权限已设置为 600 (仅所有者可读写)")

if __name__ == "__main__":
    hello_register()
