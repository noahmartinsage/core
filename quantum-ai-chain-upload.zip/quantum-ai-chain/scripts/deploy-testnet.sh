#!/bin/bash
# 量子 AI 公链 - 测试网部署脚本

set -e

echo "🚀 量子 AI 公链测试网部署脚本"
echo "=============================="

# 配置
NETWORK_NAME="quantum-ai-testnet"
CHAIN_ID=1001
INITIAL_SUPPLY="1000000000000000000000000000"  # 10 亿 QAI
VALIDATOR_COUNT=21
BLOCK_TIME=1  # 秒

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查依赖
check_dependencies() {
    echo -e "${YELLOW}检查依赖...${NC}"
    
    if ! command -v node &> /dev/null; then
        echo -e "${RED}错误：需要 Node.js${NC}"
        exit 1
    fi
    
    if ! command -v npm &> /dev/null; then
        echo -e "${RED}错误：需要 npm${NC}"
        exit 1
    fi
    
    if ! command -v rustc &> /dev/null; then
        echo -e "${YELLOW}警告：Rust 未安装，将跳过 Rust 组件编译${NC}"
    fi
    
    echo -e "${GREEN}✓ 依赖检查完成${NC}"
}

# 安装依赖
install_dependencies() {
    echo -e "${YELLOW}安装依赖...${NC}"
    
    cd contracts
    npm install
    cd ..
    
    cd wallet
    npm install
    cd ..
    
    echo -e "${GREEN}✓ 依赖安装完成${NC}"
}

# 编译智能合约
compile_contracts() {
    echo -e "${YELLOW}编译智能合约...${NC}"
    
    cd contracts
    npx hardhat compile
    cd ..
    
    echo -e "${GREEN}✓ 合约编译完成${NC}"
}

# 部署合约
deploy_contracts() {
    echo -e "${YELLOW}部署智能合约...${NC}"
    
    cd contracts
    npx hardhat run scripts/deploy.js --network testnet
    cd ..
    
    echo -e "${GREEN}✓ 合约部署完成${NC}"
}

# 初始化验证者节点
init_validators() {
    echo -e "${YELLOW}初始化验证者节点...${NC}"
    
    for i in $(seq 1 $VALIDATOR_COUNT); do
        echo "  创建验证者节点 $i/$VALIDATOR_COUNT"
        # 实际部署时需要生成密钥和配置文件
    done
    
    echo -e "${GREEN}✓ 验证者初始化完成${NC}"
}

# 启动测试网
start_testnet() {
    echo -e "${YELLOW}启动测试网...${NC}"
    
    # 启动引导节点
    # 启动验证者节点
    # 启动监控服务
    
    echo -e "${GREEN}✓ 测试网启动完成${NC}"
    echo ""
    echo "=============================="
    echo "🎉 测试网部署成功!"
    echo "=============================="
    echo "网络名称：$NETWORK_NAME"
    echo "Chain ID: $CHAIN_ID"
    echo "验证者数量：$VALIDATOR_COUNT"
    echo "出块时间：${BLOCK_TIME}s"
    echo ""
    echo "下一步:"
    echo "1. 配置钱包连接到测试网"
    echo "2. 领取测试代币"
    echo "3. 开始部署 DApp"
    echo ""
}

# 主函数
main() {
    echo ""
    check_dependencies
    install_dependencies
    compile_contracts
    deploy_contracts
    init_validators
    start_testnet
}

# 显示帮助
show_help() {
    echo "用法：$0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help      显示帮助信息"
    echo "  -c, --compile   只编译合约"
    echo "  -d, --deploy    只部署合约"
    echo "  -s, --start     只启动测试网"
    echo "  --clean         清理编译产物"
    echo ""
}

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -c|--compile)
            check_dependencies
            compile_contracts
            exit 0
            ;;
        -d|--deploy)
            check_dependencies
            install_dependencies
            compile_contracts
            deploy_contracts
            exit 0
            ;;
        -s|--start)
            start_testnet
            exit 0
            ;;
        --clean)
            rm -rf contracts/artifacts
            rm -rf contracts/cache
            echo -e "${GREEN}✓ 清理完成${NC}"
            exit 0
            ;;
        *)
            echo -e "${RED}未知选项：$1${NC}"
            show_help
            exit 1
            ;;
    esac
done

# 执行主函数
main
