# Design System: Quantum AI Chain

## 1. Visual Theme & Atmosphere

量子 AI 公链的界面是**量子力学与 AI 智能的视觉融合**——深邃的宇宙黑画布 (`#0a0e17`) 上，量子蓝 (`#667eea`) 与 AI 紫 (`#764ba2`) 的渐变如同时空涟漪。设计哲学融合了 Vercel 的工程精确性与 Claude 的温暖人文关怀，创造出既专业又亲和的开发者体验。

核心视觉特征是**深度渐变系统**——从纯黑 (`#0a0e17`) 到深空蓝 (`#111625`) 再到卡片表面 (`#1a1f2e`)，每一层都通过微妙的蓝色调变化创造深度，而非传统的灰色渐变。品牌渐变色 (`linear-gradient(135deg, #667eea 0%, #764ba2 100%)`) 应用于所有关键交互元素，形成统一的视觉语言。

**核心特征**:
- 深空黑画布 (`#0a0e17`) 营造量子科技感
- 品牌渐变 (#667eea → #764ba2) 统一所有关键交互
- 微光效果 (glow effects) 替代传统阴影
- 玻璃态 (glassmorphism) 用于悬浮元素
- 等宽字体用于数据展示，无衬线字体用于 UI

---

## 2. Color Palette & Roles

### Primary Brand
- **Quantum Blue** (`#667eea`): 主品牌色，用于主按钮、链接、焦点状态
- **AI Purple** (`#764ba2`): 次品牌色，用于渐变、强调元素
- **Brand Gradient** (`linear-gradient(135deg, #667eea 0%, #764ba2 100%)`): 核心品牌渐变

### Accent Colors
- **Success Green** (`#00ff88`): 成功状态、收益、增长指标
- **Warning Yellow** (`#ffbe00`): 警告、注意提示
- **Danger Red** (`#ff3366`): 错误、亏损、危险操作
- **Info Cyan** (`#00d9ff`): 信息提示、数据高亮

### Surface & Background
- **Void Black** (`#0a0e17`): 主页面背景，最深层次
- **Deep Space** (`#111625`): 导航栏、悬浮层背景
- **Nebula Card** (`#1a1f2e`): 卡片、容器表面
- **Elevated Surface** (`#252b3b`): 输入框、按钮背景、悬浮元素

### Text Colors
- **Primary Text** (`#ffffff`): 主标题、重要文本
- **Secondary Text** (`#a0aec0`): 次要文本、描述
- **Muted Text** (`#718096`): 弱化文本、元数据
- **Dark Text** (`#171717`): 仅用于浅色背景上的深色文本

### Border & Depth
- **Border Default** (`rgba(255, 255, 255, 0.1)`): 默认边框
- **Border Hover** (`rgba(102, 126, 234, 0.5)`): 悬浮态边框
- **Glow Effect** (`0 0 30px rgba(102, 126, 234, 0.3)`): 品牌光晕效果

### Shadow System
- **Shadow Sm** (`0 2px 8px rgba(0, 0, 0, 0.3)`): 轻微悬浮
- **Shadow Md** (`0 4px 16px rgba(0, 0, 0, 0.4)`): 卡片悬浮
- **Shadow Lg** (`0 10px 40px rgba(0, 0, 0, 0.5)`): 模态框、深层悬浮
- **Glow Shadow** (`0 0 30px rgba(102, 126, 234, 0.3)`): 品牌光晕

---

## 3. Typography Rules

### Font Family
- **Primary**: `Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif`
- **Monospace**: `'JetBrains Mono', 'Fira Code', 'Roboto Mono', 'Courier New', monospace`
- **Display**: `'Inter', sans-serif` (字重 700-800 用于大标题)

### Hierarchy

| Role | Font | Size | Weight | Line Height | Letter Spacing | Notes |
|------|------|------|--------|-------------|----------------|-------|
| Display Hero | Inter | 64px (4rem) | 800 | 1.10 | -0.02em | 最大影响力，页面标题 |
| Section Heading | Inter | 48px (3rem) | 700 | 1.20 | -0.01em | 主要分区标题 |
| Sub-heading Large | Inter | 36px (2.25rem) | 700 | 1.25 | normal | 次级分区 |
| Sub-heading | Inter | 28px (1.75rem) | 700 | 1.30 | normal | 卡片标题 |
| Card Title | Inter | 24px (1.5rem) | 600 | 1.33 | normal | 功能卡片标题 |
| Body Large | Inter | 20px (1.25rem) | 400 | 1.60 | normal | 介绍性段落 |
| Body | Inter | 16px (1rem) | 400 | 1.60 | normal | 标准正文 |
| Body Small | Inter | 14px (0.875rem) | 400 | 1.50 | normal | 紧凑文本 |
| Button / Link | Inter | 16px (1rem) | 600 | 1.50 | normal | 按钮、链接 |
| Caption | Inter | 12px (0.75rem) | 400 | 1.40 | normal | 元数据、标签 |
| Label | Inter | 14px (0.875rem) | 500 | 1.50 | normal | 表单标签 |
| Code / Data | JetBrains Mono | 14px (0.875rem) | 400 | 1.60 | normal | 代码、数据展示 |
| Micro | Inter | 11px (0.6875rem) | 400 | 1.40 | 0.05em | 最小文本 |

### Principles
- **字重驱动层级**: 使用字重 (400/500/600/700/800) 而非颜色创建层级
- **宽松正文行高**: 正文使用 1.60 行高，提升可读性
- **紧凑标题**: 标题使用 1.10-1.30 行高，创造视觉冲击力
- **等宽字体用于数据**: 所有数值、代码、地址使用等宽字体
- **响应式缩放**: 所有字体大小使用 rem 单位，支持根字体缩放

---

## 4. Component Stylings

### Buttons

**Primary Gradient**
- Background: `linear-gradient(135deg, #667eea 0%, #764ba2 100%)`
- Text: `#ffffff`
- Padding: `14px 28px`
- Radius: `12px`
- Shadow: `0 0 30px rgba(102, 126, 234, 0.3)` (光晕效果)
- Hover: `transform: scale(1.05)` + 光晕增强
- Use: 主要 CTA、关键操作

**Secondary Surface**
- Background: `#252b3b`
- Text: `#ffffff`
- Padding: `12px 24px`
- Radius: `12px`
- Border: `1px solid rgba(255, 255, 255, 0.1)`
- Hover: `border-color: rgba(102, 126, 234, 0.5)`
- Use: 次要操作、取消按钮

**Ghost Button**
- Background: `transparent`
- Text: `#667eea`
- Padding: `12px 24px`
- Radius: `12px`
- Hover: `background: rgba(102, 126, 234, 0.1)`
- Use: 低优先级操作、链接式按钮

### Cards & Containers
- Background: `#1a1f2e`
- Border: `1px solid rgba(255, 255, 255, 0.1)`
- Radius: `16px` (标准卡片) / `24px` (特色卡片)
- Padding: `32px`
- Hover: `border-color: rgba(102, 126, 234, 0.5)` + `transform: translateY(-4px)`
- Shadow: `0 4px 16px rgba(0, 0, 0, 0.4)`

### Inputs & Forms
- Background: `#252b3b`
- Text: `#ffffff`
- Padding: `14px 18px`
- Border: `1px solid rgba(255, 255, 255, 0.1)`
- Focus: `border-color: #667eea` + `box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2)`
- Radius: `12px`
- Placeholder: `#718096`

### Navigation
- Background: `rgba(17, 22, 37, 0.95)` with `backdrop-filter: blur(20px)`
- Border: `1px solid rgba(255, 255, 255, 0.1)`
- Logo: Brand gradient text
- Links: `#a0aec0` → `#ffffff` on hover
- Active: Brand gradient background
- Height: `80px`

### Badges & Tags
- Background: Tinted brand color (e.g., `rgba(0, 255, 136, 0.1)` for success)
- Text: Corresponding bright color (e.g., `#00ff88`)
- Padding: `6px 12px`
- Radius: `9999px` (pill shape)
- Font: `12px weight 600`

### Modal Overlay
- Background: `rgba(0, 0, 0, 0.9)` with `backdrop-filter: blur(10px)`
- Animation: `fadeIn 0.3s ease`
- Modal Background: `#111625`
- Border: `1px solid rgba(255, 255, 255, 0.1)`
- Radius: `24px`
- Padding: `40px`

---

## 5. Layout Principles

### Spacing System
- Base unit: `4px`
- Scale: `4px, 8px, 12px, 16px, 20px, 24px, 32px, 40px, 48px, 64px, 80px, 96px`
- Section spacing: `80px` (桌面) / `48px` (移动)
- Card padding: `32px`
- Component gap: `24px`

### Grid & Container
- Max container width: `1400px` (桌面) / `100%` (移动)
- Container padding: `40px` (桌面) / `20px` (移动)
- Feature grid: `repeat(auto-fit, minmax(350px, 1fr))`
- Card grid: `repeat(auto-fit, minmax(300px, 1fr))`

### Responsive Breakpoints
- Mobile: `< 768px`
- Tablet: `768px - 1024px`
- Desktop: `> 1024px`
- Large Desktop: `> 1400px`

### Whitespace Philosophy
- **呼吸空间**: 每个功能区之间保持 80px+ 垂直间距
- **内容岛**: 相关元素成组，组间距大于组内间距
- **视觉节奏**:  alternating 密度创造阅读节奏

---

## 6. Depth & Elevation

| Level | Treatment | Use |
|-------|-----------|-----|
| Flat (Level 0) | No shadow, no border | 页面背景、内联文本 |
| Contained (Level 1) | `1px solid rgba(255,255,255,0.1)` | 标准卡片、分区 |
| Hover (Level 2) | `border-color: rgba(102,126,234,0.5)` + `translateY(-4px)` | 卡片悬浮态 |
| Elevated (Level 3) | `0 4px 16px rgba(0,0,0,0.4)` | 悬浮卡片、下拉菜单 |
| Modal (Level 4) | `0 10px 40px rgba(0,0,0,0.5)` | 模态框、深层悬浮 |
| Glow (Special) | `0 0 30px rgba(102,126,234,0.3)` | 品牌光晕、焦点状态 |

---

## 7. Animation & Transitions

### Timing Functions
- **Ease Out**: `cubic-bezier(0.4, 0, 0.2, 1)` - 标准退出动画
- **Ease In Out**: `cubic-bezier(0.4, 0, 0.2, 1)` - 双向平滑
- **Spring**: `cubic-bezier(0.34, 1.56, 0.64, 1)` - 弹性效果

### Common Durations
- **Fast**: `150ms` - 微交互、图标动画
- **Normal**: `300ms` - 按钮、卡片、导航
- **Slow**: `500ms` - 页面过渡、模态框
- **Very Slow**: `800ms` - 大型布局变化

### Key Animations
- **fadeIn**: `from { opacity: 0; } to { opacity: 1; }`
- **slideUp**: `from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); }`
- **scaleIn**: `from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); }`
- **pulse**: `0%, 100% { opacity: 1; } 50% { opacity: 0.5; }`
- **glow**: `0%, 100% { box-shadow: 0 0 20px rgba(102,126,234,0.3); } 50% { box-shadow: 0 0 40px rgba(102,126,234,0.5); }`

---

## 8. Do's and Don'ts

### ✅ Do's
- 始终使用品牌渐变色用于主要 CTA
- 保持深色主题的一致性 (不要混入浅色背景)
- 使用光晕效果替代传统阴影
- 等宽字体用于所有数值和代码
- 保持 80px+ 的分区间距
- 悬浮态使用品牌色边框高亮

### ❌ Don'ts
- 不要使用纯黑色 (`#000000`) - 使用 `#0a0e17`
- 不要使用传统灰色渐变 - 使用蓝色调深色渐变
- 不要使用下划线链接 - 使用颜色变化
- 不要使用超过 3 层的卡片嵌套
- 不要在深色背景上使用深色文本
- 不要混用多种渐变方向 - 统一使用 135deg

---

## 9. Agent Prompt Guide

### Quick Color Reference
```
主背景：#0a0e17
卡片背景：#1a1f2e
品牌渐变：linear-gradient(135deg, #667eea 0%, #764ba2 100%)
成功色：#00ff88
警告色：#ffbe00
危险色：#ff3366
```

### Ready-to-Use Prompts
```
"创建一个量子科技感的卡片，使用深空黑背景 (#0a0e17)，卡片表面 (#1a1f2e)，品牌渐变边框悬浮效果"

"设计一个渐变按钮，使用品牌渐变 (#667eea → #764ba2)，白色文字，12px 圆角，光晕阴影"

"创建一个深色导航栏，80px 高度，毛玻璃效果，品牌渐变 Logo，悬浮链接效果"

"设计一个数据展示卡片，等宽字体显示数值，成功色 (#00ff88) 表示增长，带光晕效果"
```

---

**版本**: 1.0.0  
**创建时间**: 2026-04-06  
**灵感来源**: Claude (温暖人文) + Vercel (工程精确) + 量子科技美学  
**应用项目**: Quantum AI Chain (量子 AI 公链)
